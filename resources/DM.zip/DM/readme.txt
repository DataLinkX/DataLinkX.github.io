A note for function DM:

For GR, one should using include Gs.cpp by sourceCpp("Gs.cpp")in your workspace first.