#' DM function
#'
#' This package provides the calculation of 9 correlation measure methods, including cor, scor, Dcor, XIcor, GR, ACE, MIC, HHG and RDC.
#' At the same time, the DM function can also calculate two combined methods, harmoni mean pvalue and cauchy combine method
#'
#' @param x input
#' @param y input
#' @param method 9 single methods and 2 combine method
#' @param nsim default 200
#'
#' @return Return the p value of the corresponding method
#' @export
#'
#' @examples
#' x <- runif(100)
#' y <- x^2
#' DM(x,y,method="scor")
#' DM(x,y)
DM <- function(x, y, method = c("harmonic","pcor", "scor", "dcor","ace","rdc","hhg","gr","mic","xicor","cauchy"), nsim = 200){

  for(pkg in c("XICOR","HHG","energy","acepack","minerva","harmonicmeanp","Rcpp")){
    if(!requireNamespace(pkg,quietly=TRUE)){
      stop(paste("The ",pkg," package needed for this function to work. Please install it.",sep=""),
           call. =FALSE)
    }
  }

  method <- match.arg(method)

  val.mic2 = val.gr2 = val.rdc2 = val.ace2 <- rep(NA,nsim)  # record the null "correlations"

  if(method == "pcor"){
    pcor = cor.test(x,y)$p.value
    return(pcor)
  }
  if(method == "scor"){
    scor = cor.test(x,y,method = "spearman")$p.value
    return(scor)
  }
  if(method == "dcor"){
    library(energy)

    ddcor <- as.numeric(dcorT.test(x,y)$p.value)
    return(ddcor)
  }
  if(method == "hhg"){
    for(pkg in c("HHG")){
      if(!requireNamespace(pkg,quietly=TRUE)){
        stop(paste("The ",pkg," package needed for this function to work. Please install it.",sep=""),
             call. =FALSE)
      }
    }
    ## p-value of HHG
    library(HHG)
    mHHG<-function(x,y,k=1){
      n=length(x)
      nt=n*(n-1)
      x<-as.matrix(x)
      y<-as.matrix(y)
      px=dim(x)[2]
      nx=dim(x)[1]
      if(nx<px){
        x=t(x)
        px=dim(x)[2]
        nx=dim(x)[1]
      }
      py=dim(y)[2]
      ny=dim(y)[1]
      if(ny<py){
        y=t(y)
        py=dim(y)[2]
        ny=dim(y)[1]
      }
      if(nx!=ny){
        stop("the number of obervations of X and Y must be the same!")
      }
      else{
        Dx = as.matrix(dist(x), diag = TRUE, upper = TRUE)
        Dy = as.matrix(dist(y), diag = TRUE, upper = TRUE)
        hhg = hhg.test(Dx, Dy, nr.perm = k)
        st=hhg$sum.chisq
        st=st/nt
        return((hhg$perm.pval.hhg.sc)+0)
      }
    }
    hhg = mHHG(x,y,k=200)
    return(hhg)
  }
  if(method == "mic"){
    for(pkg in c("minerva")){
      if(!requireNamespace(pkg,quietly=TRUE)){
        stop(paste("The ",pkg," package needed for this function to work. Please install it.",sep=""),
             call. =FALSE)
      }
    }
    library(minerva)
    val.mic <- mine(x,y)$MIC
    for(i in 1:nsim){
      y_null <- sample(y)
      val.mic2[i]= mine(x,y_null)$MIC
    }
    mic <- (sum(val.mic < val.mic2)+1)/(nsim+1)
    return(mic)
  }
  if(method == "gr"){

    for(pkg in c("Rcpp")){
      if(!requireNamespace(pkg,quietly=TRUE)){
        stop(paste("The ",pkg," package needed for this function to work. Please install it.",sep=""),
             call. =FALSE)
      }
    }
    ## define GR
    library(Rcpp)
    sourceCpp('Gs.cpp',showOutput = F)

    gs <- function(x, y, ms = ceiling(sqrt(length(x))), lambda0=3.0, option)
    {
      n = min(length(x), length(y))
      x = x[1:n]
      y = y[1:n]
      x = x-mean(x)
      x = x/sqrt(mean(x^2))
      y = y-mean(y)
      y = y/sqrt(mean(y^2))

      y = y[order(x)]
      x = x[order(x)]
      mg_yx = dynG2(y, x, ms, lambda0, option)
      return (mg_yx)
    }

    mGs<-function(x,y,ms = ceiling(sqrt(length(x))), lambda0=3.0)
    {
      mg_yx = gs(x, y, ms, lambda0, 2)
      mg_xy = gs(y, x, ms, lambda0, 2)
      return (max(mg_yx,mg_xy))
    }

    tGs<-function(x,y,ms = ceiling(sqrt(length(x))), lambda0=3.0)
    {
      mg_yx = gs(x, y, ms, lambda0, 3)
      mg_xy = gs(y, x, ms, lambda0, 3)
      return (max(mg_yx,mg_xy))
    }

    Gs<-function(x,y,ms = ceiling(sqrt(length(x))), lambda0=3.0, option = 1)
    {
      mg_yx = gs(x, y, ms, lambda0, option)
      mg_xy = gs(y, x, ms, lambda0, option)
      g = rep(0, length(mg_yx))
      for (i in 1:length(mg_yx))
      {
        g[i] = max(mg_yx[i], mg_xy[i])
      }
      return (g)
    }
    GR <- function(x,y,emp=F)
    {
      if(emp){
        xn=ecdf(x)(x)
        yn=ecdf(y)(y)
        res=tGs(xn,yn)
      }else res=tGs(x,y)
      return(res)
    }
    val.gr <- GR(x,y)
    val.gr[is.nan(val.gr)] <- 1  #NAN
    for(i in 1:nsim){
      y_null <- sample(y)
      val.gr2[i] = GR(x,y_null)
    }
    val.gr2[is.nan(val.gr2)] <- 1  #NAN
    gr = (sum(val.gr < val.gr2)+1)/(nsim+1)
    return(gr)
  }
  if(method == "ace"){
    for(pkg in c("acepack")){
      if(!requireNamespace(pkg,quietly=TRUE)){
        stop(paste("The ",pkg," package needed for this function to work. Please install it.",sep=""),
             call. =FALSE)
      }
    }
    library(acepack)
    val.ace <- ace(x,y)$rsq
    for(i in 1:nsim){
      y_null <- sample(y)
      val.ace2[i] = ace(x,y_null)$rsq
    }
    aace = (sum(val.ace < val.ace2)+1)/(nsim+1)
    return(aace)
  }
  if(method == "rdc"){
    ## define RDC (randomized dependence coefficient)
    RDC <- function(x,y,k=20,s=1/6,f=sin) {
      x <- cbind(apply(as.matrix(x),2,function(u)rank(u)/length(u)),1)
      y <- cbind(apply(as.matrix(y),2,function(u)rank(u)/length(u)),1)
      x <- s/ncol(x)*x%*%matrix(rnorm(ncol(x)*k),ncol(x))
      y <- s/ncol(y)*y%*%matrix(rnorm(ncol(y)*k),ncol(y))
      res=cancor(cbind(f(x),1),cbind(f(y),1))$cor[1]
      return(res)
    }
    val.rdc <- RDC(x,y)
    for(i in 1:nsim){
      y_null <- sample(y)
      val.rdc2[i] = RDC(x,y_null)
    }
    pvalue <- (sum(val.rdc2 > val.rdc)+1)/(nsim+1)
    return(pvalue)
  }
  if(method == "xicor"){
    for(pkg in c("XICOR")){
      if(!requireNamespace(pkg,quietly=TRUE)){
        stop(paste("The ",pkg," package needed for this function to work. Please install it.",sep=""),
             call. =FALSE)
      }
    }
    library(XICOR)
    xxicor <- xicor(x,y,pvalue = TRUE)$pval
    return(xxicor)
  }
  if(method == "harmonic"){
    for(pkg in c("XICOR","HHG","energy","acepack","minerva","harmonicmeanp","Rcpp")){
      if(!requireNamespace(pkg,quietly=TRUE)){
        stop(paste("The ",pkg," package needed for this function to work. Please install it.",sep=""),
             call. =FALSE)
      }
    }
    library(harmonicmeanp)
    library(minerva)
    library(acepack)
    library(energy)
    library(XICOR)
    library(HHG)

    ## define RDC (randomized dependence coefficient)
    RDC <- function(x,y,k=20,s=1/6,f=sin) {
      x <- cbind(apply(as.matrix(x),2,function(u)rank(u)/length(u)),1)
      y <- cbind(apply(as.matrix(y),2,function(u)rank(u)/length(u)),1)
      x <- s/ncol(x)*x%*%matrix(rnorm(ncol(x)*k),ncol(x))
      y <- s/ncol(y)*y%*%matrix(rnorm(ncol(y)*k),ncol(y))
      res=cancor(cbind(f(x),1),cbind(f(y),1))$cor[1]
      return(res)
    }

    ## define GR
    library(Rcpp)

    sourceCpp('Gs.cpp',showOutput = F)

    gs <- function(x, y, ms = ceiling(sqrt(length(x))), lambda0=3.0, option)
    {
      n = min(length(x), length(y))
      x = x[1:n]
      y = y[1:n]
      x = x-mean(x)
      x = x/sqrt(mean(x^2))
      y = y-mean(y)
      y = y/sqrt(mean(y^2))
      y = y[order(x)]
      x = x[order(x)]
      mg_yx = dynG2(y, x, ms, lambda0, option)
      return (mg_yx)
    }

    mGs<-function(x,y,ms = ceiling(sqrt(length(x))), lambda0=3.0)
    {
      mg_yx = gs(x, y, ms, lambda0, 2)
      mg_xy = gs(y, x, ms, lambda0, 2)
      return (max(mg_yx,mg_xy))
    }

    tGs<-function(x,y,ms = ceiling(sqrt(length(x))), lambda0=3.0)
    {
      mg_yx = gs(x, y, ms, lambda0, 3)
      mg_xy = gs(y, x, ms, lambda0, 3)
      return (max(mg_yx,mg_xy))
    }

    Gs<-function(x,y,ms = ceiling(sqrt(length(x))), lambda0=3.0, option = 1)
    {
      mg_yx = gs(x, y, ms, lambda0, option)
      mg_xy = gs(y, x, ms, lambda0, option)
      g = rep(0, length(mg_yx))
      for (i in 1:length(mg_yx))
      {
        g[i] = max(mg_yx[i], mg_xy[i])
      }
      return (g)
    }
    GR <- function(x,y,emp=F)
    {
      if(emp){
        xn=ecdf(x)(x)
        yn=ecdf(y)(y)
        res=tGs(xn,yn)
      }else res=tGs(x,y)
      return(res)
    }

    mHHG<-function(x,y,k=1){
      n=length(x)
      nt=n*(n-1)
      x<-as.matrix(x)
      y<-as.matrix(y)
      px=dim(x)[2]
      nx=dim(x)[1]
      if(nx<px){
        x=t(x)
        px=dim(x)[2]
        nx=dim(x)[1]
      }
      py=dim(y)[2]
      ny=dim(y)[1]
      if(ny<py){
        y=t(y)
        py=dim(y)[2]
        ny=dim(y)[1]
      }
      if(nx!=ny){
        stop("the number of obervations of X and Y must be the same!")
      }
      else{
        Dx = as.matrix(dist(x), diag = TRUE, upper = TRUE)
        Dy = as.matrix(dist(y), diag = TRUE, upper = TRUE)
        hhg = hhg.test(Dx, Dy, nr.perm = k)
        st=hhg$sum.chisq
        st=st/nt
        return((hhg$perm.pval.hhg.sc)+0)
      }
    }


    val.mic = mine(x,y)$MIC
    val.rdc = RDC(x,y)
    val.gr = GR(x,y)
    val.ace = ace(x,y)$rsq

    for(i in 1:nsim){
      y_null <- sample(y)
      val.mic2[i]= mine(x,y_null)$MIC
      val.rdc2[i] = RDC(x,y_null)
      val.gr2[i] = GR(x,y_null)
      val.ace2[i] = ace(x,y_null)$rsq
    }

    val.gr[is.nan(val.gr)] <- 1  #NAN
    val.gr2[is.nan(val.gr2)] <- 1  #NAN

    ## p-value
    p.pcor = cor.test(x,y)$p.value
    p.scor = cor.test(x,y,method = "spearman")$p.value
    p.mic = (sum(val.mic < val.mic2)+1)/(nsim+1)
    p.gr = (sum(val.gr < val.gr2)+1)/(nsim+1)
    p.ace = (sum(val.ace < val.ace2)+1)/(nsim+1)
    p.rdc = (sum(val.rdc < val.rdc2)+1)/(nsim+1)
    p.dcor = as.numeric(dcorT.test(x,y)$p.value)
    p.hhg = mHHG(x,y,k=200)
    p.xicor = xicor(x,y,pvalue = TRUE)$pval
    p <- c(p.pcor, p.dcor, p.mic, p.scor,
           p.ace, p.rdc, p.gr, p.hhg, p.xicor)
    p.harmonic <- as.numeric(hmp.stat(p))
    return(p.harmonic)
  }
  if(method == "cauchy"){

    for(pkg in c("XICOR","HHG","energy","acepack","minerva","Rcpp")){
      if(!requireNamespace(pkg,quietly=TRUE)){
        stop(paste("The ",pkg," package needed for this function to work. Please install it.",sep=""),
             call. =FALSE)
      }
    }
    library(minerva)
    library(acepack)
    library(energy)
    library(XICOR)
    library(HHG)
    ## define RDC (randomized dependence coefficient)
    RDC <- function(x,y,k=20,s=1/6,f=sin) {
      x <- cbind(apply(as.matrix(x),2,function(u)rank(u)/length(u)),1)
      y <- cbind(apply(as.matrix(y),2,function(u)rank(u)/length(u)),1)
      x <- s/ncol(x)*x%*%matrix(rnorm(ncol(x)*k),ncol(x))
      y <- s/ncol(y)*y%*%matrix(rnorm(ncol(y)*k),ncol(y))
      res=cancor(cbind(f(x),1),cbind(f(y),1))$cor[1]
      return(res)
    }

    ## define GR
    library(Rcpp)

    sourceCpp('Gs.cpp',showOutput = F)

    gs <- function(x, y, ms = ceiling(sqrt(length(x))), lambda0=3.0, option)
    {
      n = min(length(x), length(y))
      x = x[1:n]
      y = y[1:n]
      x = x-mean(x)
      x = x/sqrt(mean(x^2))
      y = y-mean(y)
      y = y/sqrt(mean(y^2))
      y = y[order(x)]
      x = x[order(x)]
      mg_yx = dynG2(y, x, ms, lambda0, option)
      return (mg_yx)
    }

    mGs<-function(x,y,ms = ceiling(sqrt(length(x))), lambda0=3.0)
    {
      mg_yx = gs(x, y, ms, lambda0, 2)
      mg_xy = gs(y, x, ms, lambda0, 2)
      return (max(mg_yx,mg_xy))
    }

    tGs<-function(x,y,ms = ceiling(sqrt(length(x))), lambda0=3.0)
    {
      mg_yx = gs(x, y, ms, lambda0, 3)
      mg_xy = gs(y, x, ms, lambda0, 3)
      return (max(mg_yx,mg_xy))
    }

    Gs<-function(x,y,ms = ceiling(sqrt(length(x))), lambda0=3.0, option = 1)
    {
      mg_yx = gs(x, y, ms, lambda0, option)
      mg_xy = gs(y, x, ms, lambda0, option)
      g = rep(0, length(mg_yx))
      for (i in 1:length(mg_yx))
      {
        g[i] = max(mg_yx[i], mg_xy[i])
      }
      return (g)
    }
    GR <- function(x,y,emp=F)
    {
      if(emp){
        xn=ecdf(x)(x)
        yn=ecdf(y)(y)
        res=tGs(xn,yn)
      }else res=tGs(x,y)
      return(res)
    }

    mHHG<-function(x,y,k=1){
      n=length(x)
      nt=n*(n-1)
      x<-as.matrix(x)
      y<-as.matrix(y)
      px=dim(x)[2]
      nx=dim(x)[1]
      if(nx<px){
        x=t(x)
        px=dim(x)[2]
        nx=dim(x)[1]
      }
      py=dim(y)[2]
      ny=dim(y)[1]
      if(ny<py){
        y=t(y)
        py=dim(y)[2]
        ny=dim(y)[1]
      }
      if(nx!=ny){
        stop("the number of obervations of X and Y must be the same!")
      }
      else{
        Dx = as.matrix(dist(x), diag = TRUE, upper = TRUE)
        Dy = as.matrix(dist(y), diag = TRUE, upper = TRUE)
        hhg = hhg.test(Dx, Dy, nr.perm = k)
        st=hhg$sum.chisq
        st=st/nt
        return((hhg$perm.pval.hhg.sc)+0)
      }
    }

    val.mic = mine(x,y)$MIC
    val.rdc = RDC(x,y)
    val.gr = GR(x,y)
    val.ace = ace(x,y)$rsq

    for(i in 1:nsim){
      y_null <- sample(y)
      val.mic2[i]= mine(x,y_null)$MIC
      val.rdc2[i] = RDC(x,y_null)
      val.gr2[i] = GR(x,y_null)
      val.ace2[i] = ace(x,y_null)$rsq
    }

    val.gr[is.nan(val.gr)] <- 1  #NAN
    val.gr2[is.nan(val.gr2)] <- 1  #NAN

    ## p-value
    p.pcor = cor.test(x,y)$p.value
    p.scor = cor.test(x,y,method = "spearman")$p.value
    p.mic = (sum(val.mic < val.mic2)+1)/(nsim+1)
    p.gr = (sum(val.gr < val.gr2)+1)/(nsim+1)
    p.ace = (sum(val.ace < val.ace2)+1)/(nsim+1)
    p.rdc = (sum(val.rdc < val.rdc2)+1)/(nsim+1)
    p.dcor = as.numeric(dcorT.test(x,y)$p.value)
    p.hhg = mHHG(x,y,k=200)
    p.xicor = xicor(x,y,pvalue = TRUE)$pval
    p <- c(p.pcor, p.dcor, p.mic, p.scor,
           p.ace, p.rdc, p.gr, p.hhg, p.xicor)
    wi <- 1/length(p)
    T <- sum(wi*tan((0.5-p)*pi))
    p.cauchy <- 1-pcauchy(T)
    return(p.cauchy)
  }
}
