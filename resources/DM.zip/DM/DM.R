#' 2021-10-28
#'
#' DM function
#'
#' DM is an R function that aims to measure the dependence (association) between `x` and `y`. 
#' It integrates nine widely used algorithms (cor, scor, dcor, HHG, MIC, GR, RDC, XIcor and ACE) 
#' and two combined methods (harmonic mean and cauchy combination). 
#' 
#'
#' @param x input data x
#' @param y input data y, must have the same length with x
#' @param method takes values in (cor, scor, dcor, hhg, mic, gr, rdc, xicor, ace, harmonic and cauchy ), default is harmonic
#' @param nperm number of permutations to get the approximated p-value, default is 200
#' @param p.value whether to calculate p-value, default is FALSE
#'
#' @return Return the the correlation or p value of the corresponding method
#' @export
#'
#' @examples
#' x <- runif(100)
#' y <- x^2
#' DM(x,y)   # default harmonic
#' DM(x,y,method="mic", p.value=F)
#' DM(x,y,method="cauchy", p.value=T)
#' 
DM <- function(x, y, method = c("harmonic","pcor", "scor", "dcor","ace","rdc","hhg","gr","mic","xicor","cauchy"), p.value=F, nperm = 200){

  for(pkg in c("XICOR","HHG","energy","acepack","minerva","harmonicmeanp","Rcpp")){
    if(!requireNamespace(pkg,quietly=TRUE)){
      stop(paste("The ",pkg," package is needed for this function. Please install it.",sep=""),
           call. =FALSE)
    }
  }
  
  method <- tolower(method)
  method <- match.arg(method)
  
  library(energy)
  library(HHG)
  library(minerva)
  library(Rcpp)
  library(acepack)
  library(XICOR)
  library(harmonicmeanp)

  ## define HHG
  mHHG<-function(x,y,p.value,k=1){
    n=length(x)
    nt=n*(n-1)
    x<-as.matrix(x)
    y<-as.matrix(y)
    px=dim(x)[2]
    nx=dim(x)[1]
    if(nx<px){
      x=t(x)
      px=dim(x)[2]
      nx=dim(x)[1]
    }
    py=dim(y)[2]
    ny=dim(y)[1]
    if(ny<py){
      y=t(y)
      py=dim(y)[2]
      ny=dim(y)[1]
    }
    if(nx!=ny){
      stop("the number of obervations of X and Y must be the same!")
    }
    else{
      Dx = as.matrix(dist(x), diag = TRUE, upper = TRUE)
      Dy = as.matrix(dist(y), diag = TRUE, upper = TRUE)
      hhg = hhg.test(Dx, Dy, nr.perm = k)
      st=hhg$sum.chisq
      st=st/nt
      if(p.value){
        return(list(method = method, dm=st, p.value=(hhg$perm.pval.hhg.sc)+0))
      }else{
        return(st)
      }
    }
  }
  
  ## define GR
  sourceCpp('Gs.cpp',showOutput = F)
  gs <- function(x, y, ms = ceiling(sqrt(length(x))), lambda0=3.0, option)
  {
    n = min(length(x), length(y))
    x = x[1:n]
    y = y[1:n]
    x = x-mean(x)
    x = x/sqrt(mean(x^2))
    y = y-mean(y)
    y = y/sqrt(mean(y^2))
    
    y = y[order(x)]
    x = x[order(x)]
    mg_yx = dynG2(y, x, ms, lambda0, option)
    return (mg_yx)
  }
  mGs<-function(x,y,ms = ceiling(sqrt(length(x))), lambda0=3.0)
  {
    mg_yx = gs(x, y, ms, lambda0, 2)
    mg_xy = gs(y, x, ms, lambda0, 2)
    return (max(mg_yx,mg_xy))
  }
  tGs<-function(x,y,ms = ceiling(sqrt(length(x))), lambda0=3.0)
  {
    mg_yx = gs(x, y, ms, lambda0, 3)
    mg_xy = gs(y, x, ms, lambda0, 3)
    return (max(mg_yx,mg_xy))
  }
  Gs<-function(x,y,ms = ceiling(sqrt(length(x))), lambda0=3.0, option = 1)
  {
    mg_yx = gs(x, y, ms, lambda0, option)
    mg_xy = gs(y, x, ms, lambda0, option)
    g = rep(0, length(mg_yx))
    for (i in 1:length(mg_yx))
    {
      g[i] = max(mg_yx[i], mg_xy[i])
    }
    return (g)
  }
  GR <- function(x,y,emp=F)
  {
    if(emp){
      xn=ecdf(x)(x)
      yn=ecdf(y)(y)
      res=tGs(xn,yn)
    }else res=tGs(x,y)
    return(res)
  }
  
  ## define RDC (randomized dependence coefficient)
  RDC <- function(x,y,k=20,s=1/6,f=sin) {
    x <- cbind(apply(as.matrix(x),2,function(u)rank(u)/length(u)),1)
    y <- cbind(apply(as.matrix(y),2,function(u)rank(u)/length(u)),1)
    x <- s/ncol(x)*x%*%matrix(rnorm(ncol(x)*k),ncol(x))
    y <- s/ncol(y)*y%*%matrix(rnorm(ncol(y)*k),ncol(y))
    res=cancor(cbind(f(x),1),cbind(f(y),1))$cor[1]
    return(res)
  }
  
  ## cal mic
  cal_mic <- function(x,y,nperm,p.value=F){
    if(p.value){
      val.mic2 <- rep(NA, nperm)
      val.mic <- mine(x,y)$MIC
      for(i in 1:nperm){
        y_null <- sample(y)
        val.mic2[i]= mine(x,y_null)$MIC
      }
      mic <- (sum(val.mic < val.mic2)+1)/(nperm+1)
      return(list(method = method, dm=mine(x,y)$MIC, p.value = mic))
    }else return(mine(x,y)$MIC)
  }
  
  ## cal gr
  cal_gr <- function(x,y,nperm,p.value=F){
    if(p.value){
      val.gr2 <- rep(NA, nperm)
      val.gr <- GR(x,y)
      val.gr[is.nan(val.gr)] <- 1  #NAN
      for(i in 1:nperm){
        y_null <- sample(y)
        val.gr2[i] = GR(x,y_null)
      }
      val.gr2[is.nan(val.gr2)] <- 1  #NAN
      gr = (sum(val.gr < val.gr2)+1)/(nperm+1)
      return(list(method = method, dm=val.gr,p.value=gr))
    }else{
      if(is.nan(GR(x,y)))
        return(1)
      return(GR(x,y))
    } 
  }
  
  ## cal ace
  cal_ace <- function(x,y,nperm,p.value){
    if(p.value){
      val.ace2 <- rep(NA,nperm)
      val.ace <- ace(x,y)$rsq
      for(i in 1:nperm){
        y_null <- sample(y)
        val.ace2[i] = ace(x,y_null)$rsq
      }
      aace = (sum(val.ace < val.ace2)+1)/(nperm+1)
      return(list(method = method, dm=val.ace,p.value=aace))
    }else return(ace(x,y)$rsq)
  }
  
  ## cal rdc
  cal_rdc <- function(x,y,nperm,p.value){
    if(p.value){
      val.rdc2 <- rep(NA, nperm)
      val.rdc <- RDC(x,y)
      for(i in 1:nperm){
        y_null <- sample(y)
        val.rdc2[i] = RDC(x,y_null)
      }
      pvalue <- (sum(val.rdc2 > val.rdc)+1)/(nperm+1)
      return(list(method = method, dm=val.rdc,p.value=pvalue))
    }else return(RDC(x,y))
  }
  
  ## check the type and shape of input
  x <- as.matrix(x)
  if(dim(x)[1]>1 & dim(x)[2]>1){
    stop("x and y must be a 1-dimensional object")
  }else{
    x <- c(x)
    if(!is.numeric(x))
      stop("x and y must be numeric data")
  }
  
  y <- as.matrix(y)
  if(dim(y)[1]>1 & dim(y)[2]>1){
    stop("x and y must be a 1-dimensional object")
  }else{
    y <- c(y)
    if(!is.numeric(y))
      stop("x and y must be numeric data")
  }
  
  if(length(x) != length(y))
    stop("the number of obervations of x and y must be the same")
  
  ## Determine whether there is NA or NaN
  ## if exists, delete
  if(sum(is.na(x))+sum(is.na(y))+sum(is.nan(x))+sum(is.nan(y)) != 0){
    message("Ignore the NA/NaN value in the input data.")
    index <- intersect(intersect(which(!is.na(x)), which(!is.na(y))), intersect(which(!is.nan(x)), which(!is.nan(y))))
    x <- x[index]
    y <- y[index]
  }
  
  ## Length of x and y must be the same
  if(length(x) != length(y))
    stop("the number of obervations of x and y must be the same")
  
  
  ## standard deviation
  if(!sd(x) || !sd(y)){
    stop("The standard deviation of x and y must be non-zero")
  }
  
  if(method == "pcor"){
    if(p.value) return(list(method = method, dm=as.numeric(cor(x,y)), p.value=cor.test(x,y)$p.value))
    else return(as.numeric(cor(x,y)))
  }
  
  if(method == "scor"){
    if(p.value) return(list(method = method, dm=as.numeric(cor(x,y ,method = "spearman")), p.value=cor.test(x,y,method = "spearman")$p.value))
    else return(as.numeric(cor(x,y ,method = "spearman")))
  }
  
  if(method == "dcor"){
    if(length(x) <=3) 
      stop("The dcor method requires the input length > 3")
    if(p.value) return(list(method = method, dm=dcor(x,y), p.value=as.numeric(dcorT.test(x,y)$p.value)))
    else return(dcor(x,y))
  }
  
  if(method == "hhg") return(mHHG(x,y,p.value = p.value, k=200))
  
  if(method == "mic") return(cal_mic(x,y,nperm,p.value))
  
  if(method == "gr") return(cal_gr(x,y,nperm,p.value))
  
  if(method == "ace") return(cal_ace(x,y,nperm,p.value))
  
  if(method == "rdc") return(cal_rdc(x,y,nperm,p.value))
  
  if(method == "xicor"){
    if(p.value) return(list(method = method, dm=xicor(x,y),p.value=xicor(x,y,pvalue = TRUE)$pval))
    else return(xicor(x,y))
  }
  
  if(method == "harmonic"){
    if(length(x) <=3) 
      stop("The dcor method requires the input length > 3")
    p.pcor = cor.test(x,y)$p.value
    p.scor = cor.test(x,y,method = "spearman")$p.value
    p.mic = cal_mic(x,y,nperm,p.value=T)$p.value
    p.gr = cal_gr(x,y,nperm,p.value=T)$p.value
    p.ace = cal_ace(x,y,nperm,p.value=T)$p.value
    p.rdc = cal_rdc(x,y,nperm,p.value=T)$p.value
    p.dcor = as.numeric(dcorT.test(x,y)$p.value)
    p.hhg = mHHG(x,y,p.value=T,k=200)$p.value
    p.xicor = xicor(x,y,pvalue = TRUE)$pval
    p <- c(p.pcor, p.dcor, p.mic, p.scor,
           p.ace, p.rdc, p.gr, p.hhg, p.xicor)
    p.harmonic <- as.numeric(hmp.stat(p))
    return(list(method = method, p.value=p.harmonic))
  }
  
  if(method == "cauchy"){
    if(length(x) <=3) 
      stop("The dcor method requires the input length > 3")
    p.pcor = cor.test(x,y)$p.value
    p.scor = cor.test(x,y,method = "spearman")$p.value
    p.mic = cal_mic(x,y,nperm,p.value=T)$p.value
    p.gr = cal_gr(x,y,nperm,p.value=T)$p.value
    p.ace = cal_ace(x,y,nperm,p.value=T)$p.value
    p.rdc = cal_rdc(x,y,nperm,p.value=T)$p.value
    p.dcor = as.numeric(dcorT.test(x,y)$p.value)
    p.hhg = mHHG(x,y,p.value=T,k=200)$p.value
    p.xicor = xicor(x,y,pvalue = TRUE)$pval
    p <- c(p.pcor, p.dcor, p.mic, p.scor,
           p.ace, p.rdc, p.gr, p.hhg, p.xicor)
    wi <- 1/length(p)
    T <- sum(wi*tan((0.5-p)*pi))
    p.cauchy <- 1-pcauchy(T)
    return(list(method = method, p.value=p.cauchy))
  }
}