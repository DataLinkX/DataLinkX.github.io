//  Created by xufeiwang on 15/12/15.

#include <cstdlib>
#include <iostream>
#include <Rcpp.h>
// #include <omp.h>
#define _USE_MATH_DEFINES
#include <cmath>
#include <ctime>
#include <vector>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <utility>
using namespace std;
using namespace Rcpp;

double log_res(float m, double Mx, double My, double Sxx, double Syy, double Sxy)
{
    double res =  m*Sxx - Mx*Mx-pow(m*Sxy-Mx*My,2)/(m*Syy-My*My);
    return (log(res) - 2*log(m));
}

double index(int n, int i, int j)
{
    int ind = (2*n-i+1)*i/2+j-i-1;
    return (ind);
}

double M_cal(NumericVector* F, int n, int m, double gamma)
{ 
    NumericVector M(n+1,0.0);
    for (int i=m; i<n+1; i++)
    {
        M[i] = gamma +(*F)[i-1];
    }

    for (int i=2*m;i<n+1; i++)
    {
        for (int k=m; k<i-m+1; k++)
        {
            double temp = gamma + M[k] +(*F)[index(n,k,i)];
            if (temp> M[i])
            {
                M[i] = temp;
            }
        }
    }
    
    return M[n];
}

double B_cal(NumericVector * F, int n, int m, double gamma)
{
    NumericVector B(n+1, 0.0);
    for (int i=m; i<n+1; i++)
    {
        B[i] = gamma + (*F)[i-1];
    }
    for (int i=2*m;i<n+1;i++)
    {
        for (int k=m;k<i-m+1;k++)
        {
            B[i] = B[i] + log(1+exp(gamma+B[k]+(*F)[index(n,k,i)]-B[i]));
        }
    }
    return B[n];
}

pair<double, double> D_cal(NumericVector * F, int n, int m, double gamma)
{
    NumericVector B(n+1, 0.0);
    NumericVector D(n+1, 0.0);
    for (int i=m; i<n+1; i++)
    {
        B[i] = gamma + (*F)[i-1];
        D[i] = B[i];
    }
    for (int i=2*m;i<n+1;i++)
    {
        for (int k=m;k<i-m+1;k++)
        {
            B[i] = B[i] + log(1+exp(gamma+B[k]+(*F)[index(n,k,i)]-B[i]));
            D[i] = D[i] + log(1+exp(gamma+D[k]+log(1+exp(B[k]-D[k]))+(*F)[index(n,k,i)]-D[i]));
        }
    }
    return pair<double, double>(B[n],D[n]);
}

double B_cal_u(int n, int m, double gamma)
{
    NumericVector B(n+1, 0.0);
    for (int i=m; i<n+1; i++)
    {
        B[i] = gamma;
    }
    for (int i=2*m;i<n+1;i++)
    {
        for (int k=m;k<i-m+1;k++)
        {
            B[i] = B[i] + log(1+exp(gamma+B[k]-B[i]));
        }
    }
    return B[n];
}

pair<double,double> D_cal_u(int n, int m, double gamma)
{
    NumericVector B(n+1, 0.0);
    NumericVector D(n+1, 0.0);
    for (int i=m; i<n+1; i++)
    {
        B[i] = gamma;
        D[i] = B[i];
    }
    for (int i=2*m;i<n+1;i++)
    {
        for (int k=m;k<i-m+1;k++)
        {
            B[i] = B[i] + log(1+exp(gamma+B[k]-B[i]));
            D[i] = D[i] + log(1+exp(gamma+D[k]+log(1+exp(B[k]-D[k]))-D[i]));
        }
    }
    return pair<double,double>(B[n],D[n]);
}
// [[Rcpp::export]]
NumericVector dynG2(NumericVector x, NumericVector y, int m, double lam0, int option)
{
    int n = x.size();
    NumericVector Sxx(n+1, 0.0);
    NumericVector Syy(n+1, 0.0);
    NumericVector Sxy(n+1, 0.0);
    NumericVector Mx(n+1, 0.0);
    NumericVector My(n+1, 0.0);

    for (int i=1; i<n+1; i++)
    {
        Sxx[i] += Sxx[i-1] + (x[i-1]*x[i-1]);
        Syy[i] += Syy[i-1] + y[i-1]*y[i-1];
        Sxy[i] += Sxy[i-1] + x[i-1]*y[i-1];
        Mx[i] += Mx[i-1] + x[i-1];
        My[i] += My[i-1] + y[i-1];
    }
    int len = n*(n+1)/2;
    NumericVector *ls = new NumericVector(len);
    for (int i=0; i<n; i++)
    {
        for (int j=i+1; j<n+1; j++)
        {
            if (j-i>=m)
            {
                (*ls)[index(n,i,j)] = -(j-i)/2.0*log_res(j-i, Mx[j]-Mx[i], My[j]-My[i], Sxx[j]-Sxx[i], Syy[j]-Syy[i], Sxy[j]-Sxy[i]);
            }
        }
    }
    
    double lam = -lam0*log(n)/2;
    double alpha = lam;
 // double beta = alpha-1.5*log(n/2.0/M_PI);
    delete ls;
    double res1=0, res2=0;
    if (option == 1 || option == 2)
    {
        res1 = M_cal(ls, n, m, lam);
        res1 = 1-exp(-2.0/n*(res1-lam));
    }
    if (option == 1 || option == 3)
    {
        res2 = B_cal(ls, n, m, alpha);
        double z = B_cal_u(n,m,alpha);
        res2 = 1-exp(-2.0/n*(res2-z));
    }
    
    if (option == 1)
    {
        NumericVector result(2);
        result[0] = res1;
        result[1] = res2;
        return (result);
    }else if (option == 2){
        NumericVector result(1);
        result[0] = res1;
        return (result);
    }else{
        NumericVector result(1);
        result[0] = res2;
        return (result);
    }
}

