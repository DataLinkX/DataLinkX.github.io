rm(list=ls())
source('./capt/capt.R')


## 1. torsion anlgles 
## 2. trajectory information

protein='Ala'

path=paste('./example/',protein,'/',sep='')
file_traj=paste(path,'traj.Rdata',sep='') ## trajectory information

###### parameters for classification
m=1       # number of pair of angles
Pc=0.7         
P0=0.7            
kernel='epanechnikov' 

### kernel can be one of {"von", "gaussian", "epanechnikov"}
### to use von-mises kernel, you need to install R packages circular and NPCirc.
###

S0=500  ## percentage of the population           
Sc=10000 

tk=1 ## result file number

## define torsion angles, phi's and psi's
ids=c(c(1:m),c(1:m))
names=c(rep('phi',m),rep('psi',m))

start_id='0' # if start_id is not '0', then you should give used angles.

########################################
load(file_traj)
trajectory=traj      #trajectory information

logfile=paste('./Logs/',protein,'-',kernel,'-',tk,'-log.txt',sep='')
resultfile=paste(path,kernel,'-',tk,'.Rdata',sep='') 

cat('Log file:',logfile,'\n')
sink(logfile)
cat('====Parameters==== \n')
cat('Protein:',protein,'\n')
cat('Kernel:',kernel,'\n')
cat('S0:',S0,'\n')
cat('Sc:',Sc,'\n')
cat('P0:',P0,'\n')
cat('Pc:',Pc,'\n')
cat('Result file:',resultfile,'\n')
myenv <- new.env(parent=emptyenv()) 
myenv$cluster <- NULL
myenv$t=1
myenv$Tree <- NULL

if(as.numeric(start_id)>0)
{
  source('./capt/others.R')
  clus=node.cluster(start_id,cluster)
  nclus=cluster
  nclus[clus]=start_id
  
  names(ids)=angs
  names(names)=angs

  used=rep(0,length(ids))
  
  names(used)=angs
  used[usedn]=1
  
  assign('cluster',value=nclus,envir=myenv)
  ids=unname(ids[angs[used==0]])
  names=unname(names[angs[used==0]])
}

createTree(node.id =start_id,path=path,msize = S0,min.prob = Pc,cids=ids,cnames=names,
           trajectory=trajectory,min.size=Sc,mprob=P0,kernel=kernel)

cluster <- get('cluster',envir = myenv)
Tree <- get('Tree',envir=myenv)
nclass=length(unique(cluster))
if(nclass>1){
  trans=frame.trans(cluster = cluster,freq = TRUE,trajectory = trajectory)
  count=frame.trans(cluster = cluster,trajectory = trajectory)
}
save(S0,Sc,P0,Pc,Tree,trans,count,cluster,file=resultfile)
sink()

### plot the partition tree


source('./capt/plots.R') 
source('./capt/others.R')

class.size=apply(count,1,sum)
sc=sort(class.size)
leaf_label=paste('S',names(sc),sep='')
probs=signif(sc/sum(sc)*100,3)
probs[length(sc)]=100-sum(probs[1:(length(sc)-1)])
for(i in 1:length(sc))
{
  if(i>=6) leaf_label[i]=paste(leaf_label[i],'(',probs[i],'%)',sep='') else{
    if(i<=2) leaf_label[i]=paste(paste(leaf_label[i],'(',probs[i],'%)',sep=''),'') else
      leaf_label[i]=paste(paste(leaf_label[i],'(',probs[i],'%)',sep=''),'   ')
  }
}
names(leaf_label)=names(sc)

scrs=plot_tree(tree = Tree,leafs=unique(cluster),height = 3,width = 8,leafL=0.008,
               leaf_labels = leaf_label,cex.label = 0.8,cex.node = 1,bs.adj=0.007,
               label.adj = 0.0065,node.adj = 0.001,scale = 0.6,file='ala.pdf',
               mark=c(0.96,0.90,0.88),xticks = c(1,0.98,0.96,0.94,0.92,0.90,0.88,0.84))

####

