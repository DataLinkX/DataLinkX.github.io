The folder "capt" contains functions implementing CAPT algorithm.

The folder "example" contains data for protein ALA.

The folder "Logs" contains log files of running information of CAPT.

The file "main.R" gives an example of running CAPT.

The file "tclus.Rdata" is the true cluster labels of ALA data.