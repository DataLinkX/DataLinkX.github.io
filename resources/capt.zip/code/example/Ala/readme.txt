The folder "phi" contains data for angle "phi"s

The folder "psi" contains data for angle "psi"s

The folder "one-step" contains one-step distance of phi and psi.

The file "gaussian" is the result file from CAPT with gaussian kernel.

The file "traj.Rdata" is the trajectory information of ALA.