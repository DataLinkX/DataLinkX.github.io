ARIs <- function(files)
{
  require(mclust)
  load(files[1])
  gTree=Tree
  gclus=cluster
  load(files[2])
  eTree=Tree
  eclus=cluster
  load(files[3])
  vTree=Tree
  vclus=cluster
  
  ari1 <- NULL
  ari2 <- NULL
  ari3 <- NULL
  t=1
  for(cutoff in seq(0.99,0.7,by=-0.01))
  {
    cat('cutoff=',cutoff,'\n')
    clus1=cutoff_clas(gTree,gclus,cutoff)
    clus2=cutoff_clas(eTree,eclus,cutoff)
    clus3=cutoff_clas(vTree,vclus,cutoff)
    ari1[t]=adjustedRandIndex(clus1,clus2) ## g,e
    ari2[t]=adjustedRandIndex(clus1,clus3) ## g,v
    ari3[t]=adjustedRandIndex(clus2,clus3) ## e,v
    t=t+1
  }
  return(rbind(ari1,ari2,ari3))
}
subTree <- function(node,Tree)
{
  n=length(Tree)
  sub <- NULL
  m=nchar(node)
  for(i in 1:n){
    nodes=Tree[[i]]$node.id
    temp=substr(nodes,1,m)
    if(temp==node) sub[i]=T else sub[i]=F
  }
  stree <- NULL
  t=1
  for(i in 1:n)
  {
    if(sub[i])
    {
      stree[[t]]=Tree[[i]]
      t=t+1
    }
  }
  return(stree)
}

cutoff_clas <- function(Tree,cluster,cutoff)
{
  temp_tree=treeCut(Tree,cutoff)
  leafs=treeLeafs(temp_tree)
  nclus=cluster
  for(clas in leafs)
  {
    clus=node.cluster(clas,cluster = cluster)
    nclus[clus]=clas
  }
  return(nclus)
}
treeCut <- function(Tree,cutoff)
{
  n=length(Tree)
  scores <- NULL
  nodes <- NULL
  deep <- NULL
  for(i in 1:n){
    scores[i]=Tree[[i]]$score
    nodes[i]=Tree[[i]]$node.id
    deep[i]=nchar(nodes[i])
  }
  names(scores)=nodes
  names(deep)=nodes
  udeep=sort(unique(deep))
  udeep=unname(udeep)
  nodei=1:n
  ### if parent's score belows cutoff, then child's score is also
  for(dp in udeep){
    dps=nodei[deep==dp]
    dk=length(dps)
    if(dk>0){
      for(j in 1:dk){
        i=dps[j]
        if(scores[i]<cutoff){
          child=Tree[[i]]$childs
          nc=length(child)
          for(jj in 1:nc){
            if(is.element(child[jj],nodes)) scores[child[jj]]=0
          }
        }
      }
    }
  }
  tree <- NULL
  t=1
  for(i in 1:n){
    if(scores[i]>cutoff){
      tree[[t]] <- Tree[[i]]
      t=t+1
    }
  }
  return(tree)
}
treeLeafs <- function(Tree)
{
  nodes<- NULL
  leafs <- NULL
  n=length(Tree)
  for(i in 1:n)
  {
    nodes[i]=Tree[[i]]$node.id
  }
  for(i in 1:n)
  {
    child=Tree[[i]]$childs
    nc=length(child)
    for(j in 1:nc)
    {
      if(!is.element(child[j],nodes)){
        leafs=c(leafs,child[j])
      }
    }
  }
  return(leafs)
}
adjustTable <- function(vector,ncol=9,name='L')
{
  n=length(vector)
  k=floor(n/ncol)+1
  if((k-1)*ncol==n) k=k-1
  mat <- NULL
  rowname <- NULL
  for(i in 1:k)
  {
    if(i<k){
    index=(1+ncol*(i-1)):(i*ncol)
    temp=vector[index]
    names=paste(name,index,sep='')
    }else{
    index=(ncol*(k-1)+1):n
    temp=c(vector[index],rep(0,ncol-length(index)))
    names=paste(name,(ncol*(k-1)+1):(ncol*k),sep='')
    }
    mat=rbind(mat,names,temp)
    rowname=c(rowname,'Cluster','LDc')
  }
  mat=unname(mat)
  mat=as.matrix(mat)
  mat=cbind(rowname,mat)
  return(mat)
}

sortSize <- function(start_id='0',cluster)
{
  if(as.numeric(start_id>0)) subclus=node.cluster(start_id,cluster) else 
    subclus=rep(T,length(cluster))
  
  sclus=unique(cluster[subclus])
  
  sc=clusterSize(cluster)
  sc=sc[sclus]
  sc=sort(sc)
  
  return(sc)
}

dataFold <- function(start_id='0',data_index=NULL,cluster,cdata,path='./data/',jobsize=7000)
{
  dim=dim(cdata)[1]
  sc=sortSize(start_id,cluster)
  cnames=names(sc)
  pnames=paste('P',1:length(sc),sep='')
  ids=1:length(cluster)
  if(is.null(data_index)) data_index=1:length(sc) 
  
  snames=paste('P',data_index,sep='')
  N=length(snames)
  it=1
  cat('Data Fold:',path,'\n')
  pb <- txtProgressBar(min=1,max=N,style=3)
  for(sname in snames)
  {
    #cat(paste('Write ',it,'-th/',N,sep=''),'data....')
    temp_path=paste(path,sname,'/',sep='')
    dir.create(temp_path,showWarnings = F,recursive = T)
    
    sub= cluster==cnames[which(pnames==sname)]
    sid=ids[sub]
    data=cdata[,sid]
    n=length(sid)
    dfile=paste('data','.txt',sep='')
    dfile=paste(temp_path,dfile,sep='')
    parameter=paste(temp_path,'parameter.Rdata',sep='')
    if(n<10000) mt=2 else mt=floor(n/jobsize)+1
    save(n,dim,mt,file=parameter)
    write.table(t(data),file=dfile,row.names = F,col.names = F)
   # cat('Done !\n')
    it=it+1
    setTxtProgressBar(pb,it)
  }
  cat('\n')
}
frameID <- function(k,node,cluster)
{
  ids=1:length(cluster)
  sub=ids[cluster==node]
  return(sub[k])
}
clusterSize <- function(cluster)
{
  clus=unique(cluster)
  n=length(clus)
  sz <- NULL
  for(i in 1:n)
  {
    sz[i]=sum(cluster==clus[i])
  }
  names(sz)=clus
  return(sz)
}
node.cluster <- function(node.id,cluster,verbose = F)
{
  clas=unique(cluster)
  if(verbose)
    cat('node ID:',node.id,'\n')
  ncluster=rep(0,length(cluster))
  if(is.element(node.id,clas)){
    ncluster[cluster==node.id]=1
    ncluster=as.logical(ncluster)
    return(ncluster)
  }else{
    m=nchar(node.id)
    temp=lapply(clas,substr,start=1,stop=m)
    temp=unlist(temp)
    n=length(clas)
    for(i in 1:n)
    {
      if(temp[i]==node.id) ncluster[cluster==clas[i]]=1
    }
    ncluster=as.logical(ncluster)
    return(ncluster)
  }
}
getInfo <- function(rho,cluster,names,dis=NULL,d0=NULL)
{
  n=length(names)
  hmaxk <- NULL
  LDc <- NULL
  maxC <- NULL
  maxck <-NULL
  ids=1:length(cluster)
  LDa <-NULL
  for(i in 1:n)
  {
    sub= cluster==names[i]
    sid=ids[sub]
    trho=rho[[i]]
    LDc[i]=max(trho)
    maxck[i]=which.max(rho[[i]])
    hmaxk[i]=sid[maxck[i]]
    maxC[i]=sum(trho==LDc[i])
    if(!is.null(dis))
      LDa[i]=sum(dis[[i]]<=d0)
  }
  return(list(maxk=hmaxk,LDc=LDc,maxC=maxC,maxck=maxck,LDa=LDa))
}
histDen <- function(x,dh=pi/40)
{
  breaks=seq(-pi-dh,pi+dh,by=dh)
  k=length(breaks)-1
  breaks[k+1]=breaks[k+1]+0.00000001
  n=length(x)
  xx=c(x-2*pi,x,x+2*pi)
  den <- NULL
  denx <- NULL
  denxy <-NULL
  for(i in 1:k)
  {
    ind= xx>=breaks[i] & xx< breaks[i+1]
    den[i]=sum(ind)/n/(breaks[i+1]-breaks[i])
  }
  for(i in 1:k)
  {
    denx[i]=(breaks[i]+breaks[i+1])/2
    denxy[i]=(den[i]+den[i+1])/2
  }
  denxy=denxy[denx>min(x) & denx<= pi]
  denx=denx[denx>min(x) & denx<= pi]
  return(list(den=den,breaks=breaks,denx=denx,denxy=denxy))
}