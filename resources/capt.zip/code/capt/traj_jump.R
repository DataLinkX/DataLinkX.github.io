frame.trans <- function(cluster,trajectory=NULL,freq=FALSE)
{
  ### cluster: 1,2,...,m
  # cluster=as.numeric(cluster)
  clas=unique(cluster)
  clas=sort(clas)
  n=length(clas)
  # clas=sort(clas)
  ctemp=clas
  
  newcluster <- NULL
  for(i in 1:n)
  {
    newcluster[cluster==clas[i]]=i
  }
  
  cluster=newcluster
  cluster=as.numeric(cluster)
  clas=unique(cluster)
  clas=sort(clas)
  
  count <- array(0,dim=c(n,n))
  
  if(is.null(trajectory) || (length(trajectory)==1)) trajectory=rep(1,length(cluster))
  
  trajs=unique(trajectory)
  n.trajs=length(trajs)
  
  for(i in 1:n.trajs)
  {
    cluster.traj=cluster[trajectory==trajs[i]]
    temp=frame.trans.count(clas,cluster=cluster.traj)
    count=count+temp
  }
  rownames(count)=ctemp
  colnames(count)=ctemp
  if(freq)
  {
    for(i in 1:n)
    {
      temp=count[i,]/sum(count[i,])
      temp[is.nan(temp)]=0
      count[i,]=temp
    }
  }
  return(count)
}
frame.trans.count <- function(clas,cluster)
{
  n=length(clas)
  count <- array(0,dim=c(n,n))
  m=length(cluster)
  frame.ids=1:m
  
  for(i in 1:n)
  {
    curi=frame.ids[cluster==clas[i]]
    if(length(curi)>0)
    {
      nexti=curi+1
      nexti=nexti[nexti<=m]
      nextc=cluster[nexti]
      unexs=unique(nextc)
      k=length(unexs)
      if(k>0)
      {
        
        for(j in 1:k)
        {
          count[i,unexs[j]]=sum(nextc==unexs[j])
        }
      }
    }
  }
  return(count)
}