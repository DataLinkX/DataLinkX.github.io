source('./capt/peaks.R')
createTree <- function(node.id='0',cnames,cids,trajectory,msize,
                       min.prob=0.99,min.size=5000,path,kernel='gaussian',mprob)
{ 
  ### S0=msize, Sc=min.size, P0=mprob, Pc=min.prob
  cat('------------------\n')
  if(as.numeric(node.id)==0) cat(paste('Construct root node ',node.id,':',sep=''),'') else
    cat(paste('Construct node ',node.id,':',sep=''),'')
  
  if(length(cnames)>0)
  {
    cluster <- get('cluster',envir = myenv)
    if(as.numeric(node.id)>0) class_s=sum(cluster==node.id) else  class_s=Inf
    
    if(class_s>min.size)
    {
  
      res=parition_score(cluster=cluster,class=node.id,names=cnames,ids=cids,
                         msize=msize,path=path,trajectory=trajectory,kernel=kernel,mprob=mprob)
      
      mscore=res$score
    }else mscore=-1
    
    if(mscore==-1){cat('End (Cluster size is too small)\n')} else{
      if(mscore==0) cat('End (All angles have one modes)\n') else
      {
        if(mscore>min.prob){
          
          sangi=res$sangi
          sname=cnames[sangi]
          
          tcluster=res$cluster
          
          cat(paste(sname,cids[sangi],sep=''),'is selected,',paste('score=',mscore,sep=''),'\n')
          
          assign('cluster',value=tcluster,envir=myenv)
          snp=res$snp
          
          node=list(node.id=node.id,childs=paste(node.id,(1:snp),sep=''),score=mscore,
                    s.name=sname,s.id=cids[sangi])
          
          t=get('t',envir=myenv)
          Tree=get('Tree',envir=myenv)
          Tree[[t]] = node 
          assign('Tree',value=Tree,envir=myenv)
          
          ### update index
          assign('t',value=t+1,envir=myenv)
          
          for(i in 1:snp)
          {
            new.node=paste(node.id,i,sep='')
            createTree(node.id=new.node,cnames=cnames,cids=cids,
                       min.prob=min.prob,msize = msize,min.size = min.size,
                       path = path,trajectory = trajectory,mprob=mprob,kernel=kernel)
          } 
          
        }else cat('End (Partition score belows the threshold) \n')
      }
    }
  } else cat('End (All variable are used)\n')
}
parition_score <- function(cluster,class,names,ids,msize,mprob,path='./',trajectory=1,kernel)
{
  #cat('mprob=',mprob,'msize=',msize,'kernel=',kernel,'class=',class,'\n')
  tclus=cluster
  save(tclus,file='tclus.Rdata')
  n=length(names)
  pscore <- NULL
  for(i in 1:n)
  {
    pscore[[i]]=find.peaks2(name = names[i],angi = ids[i],class = class,cluster = cluster,
                    msize = msize,path=path,trajectory = trajectory,kernel=kernel,mprob = mprob)
    
    #cat(paste(names[i],ids[i],':','cscore=',pscore[[i]]$score,sep=''),'\n')
  }
  max_score=pscore[[1]]$score
  sangi=1
  ncluster=pscore[[1]]$cluster
  snp=pscore[[1]]$npeaks
  
  if(n>1)
  {
    for(i in 2:n)
    {
	   temp=pscore[[i]]
     #cat('cscore=',pscore[[i]]$score,'mscore=',max_score,names[i],ids[i],'\n')
      if(is.na(temp$score) || is.na(temp$npeaks)){
        cat('ang=',names[i],ids[i],'\n')
      }
      cscore=temp$score
      cnp=temp$npeaks
      
      if(cnp>1 && cscore>max_score){
        max_score=cscore
        sangi=i
        snp=cnp
        ncluster=temp$cluster
      }
    }
  }
  return(list(score=max_score,sangi=sangi,snp=snp,cluster=ncluster))
}
