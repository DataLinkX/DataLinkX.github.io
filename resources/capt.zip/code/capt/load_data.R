generate.folds <- function(path)
{
  path1=paste(path,'phi/',sep='')
  dir.create(path1,recursive = T)
  path1=paste(path,'psi/',sep='')
  dir.create(path1,recursive = T)
  path1=paste(path,'one-step/phi/',sep='')
  dir.create(path1,recursive = T)
  path1=paste(path,'one-step/psi/',sep='')
  dir.create(path1,recursive = T)
  path1=paste(path,'pca/',sep='')
  dir.create(path1,recursive = T)
  path1=paste(path,'pca-one-step/',sep='')
  dir.create(path1,recursive = T)
}

load.angle <- function(name,angi,path='./')
{

  file=paste(path,name,'/',name,angi,'.Rdata',sep='')
  if(!file.exists(file)) {
    cat('Load angle: Data file for \'',paste(name,angi,sep=''),'\' do not exist!')
    return(NULL)
    }else{
      load(file)
      return(angV)
    }
}

load.one.step.dis <- function(name,angi,path='./')
{
  dfile=paste(path,'one-step/',name,'/','one-step-',name,angi,'.Rdata',sep='')
  if(!file.exists(dfile)){
    stop('one-step-distance Data file for ',paste(name,angi,sep=''),'do not exist!')
  }else{
    load(dfile)
    return(dang)
  }
}

load.triangs <- function(sub=NULL,name1='phi',name2='psi',c1=NULL,c2=NULL,path='./',tri=TRUE)
  {
    if(is.null(c1)) c1=c2
    if(is.null(c2)) c2=c1
    
    if(length(c1)==1) c1=1:c1
    if(length(c2)==1) c2=1:c2
    
    temp <- NULL
    c1=unname(c1)
    c2=unname(c2)
    if(!is.null(c1))
    {
      for(i in c1)
      {
        angv=load.angle(name = name1,angi = i,path = path)
        if(!is.null(angv))
        {
          if(!is.null(sub)) angv=angv[sub]
          if(tri)
          {
            sinv=sin(angv)
            cosv=cos(angv)
            temp=rbind(temp,sinv,cosv)
          }else{
            temp=rbind(temp,angv)
          }

        }
      }
    }
    
    if(!is.null(c2))
    {
      for(i in c2)
      {
        angv=load.angle(name = name2,angi = i,path = path)
        if(!is.null(angv))
        {
          if(!is.null(sub)) angv=angv[sub]
          if(tri)
          {
            sinv=sin(angv)
            cosv=cos(angv)
            temp=rbind(temp,sinv,cosv)
          }else{
            temp=rbind(temp,angv)
          }
        }
      }  
    }
    temp=unname(temp)
    # rownames(temp)=c(paste(name1,c1,sep=''),paste(name2,c2,sep=''))
    return(temp)  
}