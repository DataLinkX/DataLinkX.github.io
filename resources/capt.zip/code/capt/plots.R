
plot_tree <- function(tree,leafs,cex.label,cex.node,leafL,scale=20,file=NULL,
                      leaf_labels=NULL,label.adj=0.02,node.adj=0.013,marks=NULL,
                      height=5,width=5,xticks=NULL,bs.adj=0.007)
{
  nf=length(leafs)
  sleaf=sort(leafs)
  dh=height/nf
  leaf_h<-NULL
  for(i in 1:nf)
  {
    leaf_h[sleaf[i]]=dh*(i-1)
  }
  names(leaf_h) <- sleaf
  #cat(leaf_h,'\n')
  locate = fix_position(tree,leafs,leaf_h,scale)
  n=length(tree)
  scors <-NULL
  for(i in 1:n)
  {
    scors[i]=tree[[i]]$score
  }
  xend=-log(scors)*scale
  if(!is.null(file)) pdf(file=file,useDingbats = F,height = height+4,width =width)
  plot(x=0,y=0,xlim=c(min(xend)*0.8,max(xend)*1.25),ylim=c(-1,height*1.01),
       xlab='',ylab='',xaxt='n',yaxt='n',col='white')
  for(i in 1:n)
  {
    cnode=tree[[i]]$node.id
    child=tree[[i]]$childs
    nc=length(child)
    
    px=locate[cnode,1]
    py=locate[cnode,2]
    ang=tree[[i]]$s.name
    angi=tree[[i]]$s.id
    #    if(nc==2)
    #    { #bquote(psi[.(angi)])
    
    if(ang=='psi'){
      text(px+node.adj,py,labels=bquote(psi[.(angi)]),col='red',cex = cex.node)
    }else
      text(px+node.adj,py,labels=bquote(phi[.(angi)]),col='red',cex = cex.node) 

#          if(ang=='psi') text(px+node.adj,py-0.1,labels=expression(psi),col='red',cex = cex.node) else{
#            if(px>-log(0.9)*scale) text(px+node.adj*2,py+0.1,labels='S01',col='red',cex = cex.node*0.8) else
#              text(px+node.adj*2,py+0.1,labels='S02',col='red',cex = cex.node*0.8)
#            text(px+node.adj,py-0.1,labels=expression(phi),col='red',cex = cex.node)
#          }

    
    equal_adj=px/20
    
    for(j in 1:nc)
    {
      if(is.element(child[j],leafs)){
        cy=leaf_h[child[j]]
        cx=px+leafL
        if(cx>px) tx=cx else tx=px+equal_adj
        text(tx+label.adj,cy,labels=leaf_labels[child[j]],cex = cex.label)
      }else{
        cx=locate[child[j],1]
        cy=locate[child[j],2]
      }
      lines(x=c(px,px),y=c(py,cy))
      if(cx-px>0)lines(x=c(px,cx),y=c(cy,cy)) else {
        if(cx>px){
          equal_adj=equal_adj
          lines(x=c(px,px+equal_adj),y=c(cy,cy))
          text(x=px+equal_adj+node.adj+bs.adj,y=cy,labels = paste('(',signif(tree[[i]]$score,4),')',sep=''),
               col='orange',cex=cex.label)
        }else{
          lines(x=c(px,px+equal_adj),y=c(cy,cy))
          text(x=px+equal_adj+node.adj+bs.adj,y=cy,labels = paste('(',signif(tree[[i]]$score,4),')',sep=''),
               col='blue',cex=cex.label)
          locate[child[j],1]=px+equal_adj
        }
      }
    }
    
  }
  if(!is.null(marks))
  {
    cmarks=-log(marks)*scale
    nm=length(marks)
    for(i in 1:nm)
    {
      lines(x=c(cmarks[i],cmarks[i]),y=c(-dh*2,height),col='grey',lty=2,lwd=1)
      #abline(v=cmarks[i],col='grey',lty=2,lwd=1)
      #text(x=cmarks[i],y=0,labels = marks[i],col='red')
    }
  }
  scors=signif(scors,2)
  if(is.null(xticks)) xaxis=seq(from=max(scors),to=min(scors),by=-0.02) else xaxis=xticks
  cxss=-log(xaxis)*scale
  axis(1,at = cxss,labels =xaxis ,pos = -1*dh, cex.axis=0.8)
  mtext(side = 1,text='Parition Score',line=-1.5,cex=0.8)
  #text(-log(0.92)*scale,-1,labels = 'score=0.92',cex=0.6,col='red')
  #text(-log(0.91)*scale,-1,labels = 'score=0.91',cex=0.6,col='red')
  #text(-log(0.928)*scale,dh,labels = 'P116',cex=0.6)
  if(!is.null(file)) dev.off()
  return(scors)
}
fix_position <- function(tree,leafs,leaf_h,scale)
{
  n_nodes=length(tree)
  fixed=rep(1,n_nodes)
  
  deep <- NULL
  nodes <-NULL
  for(i in 1:n_nodes)
  {
    deep[i]=nchar(tree[[i]]$node.id)
    nodes[i]=tree[[i]]$node.id
  }
  locate = array(0,dim=c(n_nodes,2)) ### x,y
  rownames(locate)=nodes
  
  nodeID=1:n_nodes
  fixed=rep(1,n_nodes)
  names(fixed)=nodes
  
  while(sum(fixed)>0)
  {
    for(i in 1:n_nodes)
    {
      ci=i
      child=tree[[ci]]$childs
      nc=length(child)
      hs <-NULL
      ready=T
      for(j in 1:nc)
      {
        if(is.element(child[j],leafs)){
          lfi=match(child[j],leafs)
          hs[j]=leaf_h[leafs[lfi]]
        }else{
          hs[j]=locate[child[j],2]
          if(hs[j]==0) ready=F
        }
      }
      if(ready)
      {
        locate[nodes[ci],1]=-log(tree[[ci]]$score)*scale
        locate[nodes[ci],2]=mean(hs)
        fixed[nodes[ci]]=0
      }
    }
  }
  return(locate)
}
drawrect <- function(xright,xleft,ybelow,ytop,col='red')
{
  lines(c(xright,xright),c(ybelow,ytop),col=col)
  lines(c(xright,xleft),c(ybelow,ybelow),col=col)
  lines(c(xright,xleft),c(ytop,ytop),col=col)
  lines(c(xleft,xleft),c(ybelow,ytop),col=col)
}
plot_ang <- function(name = 'phi',angi = 27,path='../hp380K/',pdfile=NULL,msize=0.009,dh=pi/80,
                     class = '0',cluster = NULL,trajectory = 1,kernel='gaussian',mprob=0.7)
{
  source('peaks.R')
  
  v.ang=load.angle(name=name,angi=angi,path=path)
  
  if(length(v.ang)>0){
    
    if(!is.null(class) && as.numeric(class)>0){
      clus=(cluster==class)
    }else{
      clus=rep(T,length(v.ang))
    }
    if(!is.null(pdfile)) png(pdfile)
    
    peak=find.peaks2(name = name,angi = angi,path=path,msize = msize,mprob=mprob,
                     class = class,cluster = cluster,trajectory = trajectory,kernel = kernel)
    
    cat(paste(name,angi,':',sep=''),'Score=')
    cat(peak$score,'with',peak$npeaks,'clusters \n')
    
    cls <- peak$cluster
    mc=unique(cls[clus])
    m=length(mc)
    cols=rainbow(m)
    p<-NULL
    count <- NULL
    
    if(m>1)
    {
      for(i in 1:m)
      {
        ssv=v.ang[cls==mc[i]]
        p[[i]]<- hist(ssv,breaks=seq(-pi,pi,dh),plot = F) 
        count[i]=max(p[[i]]$counts)
      }
      t=which.max(count)
      plot(p[[t]],col=cols[t],xlim=c(-pi,pi),main='',xlab='',ylab='',yaxt='n')
      for(i in 1:m)
      {
        if(i!=t)
        {
          plot(p[[i]],col=cols[i],add=T)
        }
      }
      
    }else  hist(v.ang[clus],breaks=seq(-pi,pi,dh),main='') 
    
    #lines(peak$denx,peak$deny,col='black')
    
    
    if(name=='psi') mtext(bquote(psi[.(angi)]),line=0.25,cex=1.3) else
      mtext(bquote(phi[.(angi)]),line=0.25) 
    #     if(name=='psi')  mtext(bquote(psi),line=0.25) else
    #               mtext(bquote(phi),line=0)
    #   
    if(!is.null(pdfile)) dev.off()
    return(peak)
  }
}
plot.one.step.angle.dis <- function(name,angi,path)
{
  value=load.one.step.dis(name = name,angi = angi,path=path)
  hist(value,xlab='',main='',ylab='',freq = F)
  abline(v=quantile(value,0.95),col='blue',lty='dashed',lwd=1.5)
  abline(v=quantile(value,0.5),col='red',lty='dashed',lwd=1.5)
  box()
}
