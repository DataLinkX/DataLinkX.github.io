source('./capt/load_data.R')
MADs <- function(Matrix,v)
{
  values=Matrix
  values=as.matrix(values)
  v1=v
  n=dim(values)[2]
  m=dim(values)[1]
  
  res1=abs(values-matrix(rep(v1,n),ncol=n))
  res2=abs(values-matrix(rep(v1,n),ncol=n)+2*pi)
  res3=abs(-values+matrix(rep(v1,n),ncol=n)+2*pi)
  res=array(0,dim=c(dim(values),3))
  res[,,1]=res1
  res[,,2]=res2
  res[,,3]=res3
  dis=apply(res,c(1,2),min)
  dis=apply(dis,2,mean)
  return(dis)
}
MAD <- function(v1,v2)
{
  n=length(v1)
  m=length(v2)
  if(n!=m){
    cat('protein_Dis: Error! \n')
    return(0)
  }else{
    res1=abs(v1-v2)
    res2=abs(2*pi+v1-v2)
    res3=abs(2*pi+v2-v1)
    res=rbind(res1,res2,res3)
    res=apply(res,2,min)
    dis=mean(res)
    return(dis)
  }
}
oneStep_MAD <- function(proteins)
{
  n=dim(proteins)[2]
  dis <- NULL
  pb <- txtProgressBar(min=1,max=n-1,style=3)
  for(i in 1:(n-1))
  {
    dis[i]=MAD(proteins[,i],proteins[,i+1])
    setTxtProgressBar(pb,i)
  }
  return(dis)
}
ang_disVx <- function(v,x=NULL) ### x, v  dif.ang.vector
{ 
  if(is.null(x)){
    n=length(v)
    v=v[1:(n-1)]
    x=v[2:n]
  }
  dis1=abs(2*pi+v-x)
  dis2=abs(2*pi+x-v)
  dis3=abs(v-x)
  ans=cbind(dis1,dis2,dis3)
  ans=apply(ans,MARGIN = 1,min)
  return(ans)
}
ang_dis_traj <- function(v1,trajectory=NULL)
{
  n=length(v1)
  if(is.null(trajectory)) trajectory=rep(1,n)
  trajs=unique(trajectory)
  m=length(trajs)
  ids=1:n
  res <- NULL
  if(m>1)
  pb <- txtProgressBar(min=1,max=m,style=3)
  for(i in 1:m)
  {
    s=ids[trajectory==trajs[i]]
    ans=ang_disVx(s)
    res <- c(res,ans)
    if(m>1)
    setTxtProgressBar(pb,i)
  }
  return(res)
}
OneStep_AD <- function(angv=NULL,name,angi,path='./',trajectory=NULL) ## one-step angle distance
{
  if(is.null(angv))
  {
    angv=load.angle(name=name,angi=angi,path=path)
    if(!is.null(angv)) dang=ang_dis_traj(angv,trajectory) else dang=NULL
    save(dang,file=paste(path,'one-step/',name,'/','one-step-',name,angi,'.Rdata',sep=''))
  }else{
    dang=ang_dis_traj(angv,trajectory)
    return(dang)
  }
}
angle.one.step.all <- function(angV=NULL,name,m,path,trajectory=NULL)
{
  pb <- txtProgressBar(min=1,max=m,style=3)
  for(i in 1:m)
  {
    OneStep_AD(angv = angV,name = name,angi = i,path=path,trajectory = trajectory)
    setTxtProgressBar(pb,i)
  }
}



