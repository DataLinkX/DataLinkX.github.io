rmsd2pdb <- function(pdb1,pdb2,atoms=NULL)
{
  xx=read.pdbxyz(pdb1,sub=atoms)
  yy=read.pdbxyz(pdb2,sub=atoms)
  rmsd=mrmsd(xx,yy)
  return(rmsd)
}
rmsd2file <- function(file1,file2,atoms=NULL)
{
  xx=read.frame(file1,sub=atoms)
  yy=read.frame(file2,sub=atoms)
  rmsd=mrmsd(xx,yy)
  return(rmsd)
}

rmsd.pdbs <- function(i,pdbs,ref=NULL,atoms=NULL)
{
  source('rmsd.R')
  if(is.null(atoms)) atoms=heavy.atoms
  if(is.null(ref)){
    ref=pdbs[1]
    xx=read.pdbxyz(pdb = ref,sub=atoms)
  }else xx=ref
  yy=read.pdbxyz(pdb=pdbs[i],sub=atoms)

  rmsd=mrmsd(xx,yy)
  return(rmsd)
}
mrmsd <- function(xx,yy)
{
  # xx and yy with size 3*n
  # ,xfit = rep(TRUE, length(xx)), yfit = xfit, verbose = FALSE) 
  #   xx <- matrix(xx, nrow = 3, )
  #   x <- matrix(xx[xfit], nrow = 3, )
  #   y <- matrix(yy[yfit], nrow = 3, )
  #   print(xx)
  x <- xx
  y <- yy
  if (length(x) != length(y)) 
    stop("dimension mismatch in x and y")
  xbar <- apply(x, 1, mean)
  ybar <- apply(y, 1, mean)
  xx <- sweep(xx, 1, xbar)
  x <- sweep(x, 1, xbar)
  y <- sweep(y, 1, ybar)
  R <- y %*% t(x)
  RR <- t(R) %*% R
  prj <- eigen(RR)
  prj$values[prj$values < 0 & prj$values >= -1e-12] <- 1e-12
  A <- prj$vectors
  b <- A[, 1]
  c <- A[, 2]
  A[1, 3] <- (b[2] * c[3]) - (b[3] * c[2])
  A[2, 3] <- (b[3] * c[1]) - (b[1] * c[3])
  A[3, 3] <- (b[1] * c[2]) - (b[2] * c[1])
  B <- R %*% A
  B <- sweep(B, 2, sqrt(prj$values), "/")
  b <- B[, 1]
  c <- B[, 2]
  B[1, 3] <- (b[2] * c[3]) - (b[3] * c[2])
  B[2, 3] <- (b[3] * c[1]) - (b[1] * c[3])
  B[3, 3] <- (b[1] * c[2]) - (b[2] * c[1])
  U <- B %*% t(A)
  xx <- U %*% xx
  
  x <- U %*% x
  frmsd <- sqrt(sum((x - y)^2)/dim(y)[2])
  #   cat("#rmsd= ", round(frmsd, 6), "\n")
  
  xx <- sweep(xx, 1, ybar, "+")
  as.vector(xx)
  r=ybar-U %*% xbar
  
  #   return(list(rmsd=frmsd,R=U,Trans=r))
  return(frmsd)
}
rmsd.fit <- function(xx,yy,sub=NULL)
{
  # xx and yy with size 3*n
  # ,xfit = rep(TRUE, length(xx)), yfit = xfit, verbose = FALSE) 
  #   xx <- matrix(xx, nrow = 3, )
  #   x <- matrix(xx[xfit], nrow = 3, )
  #   y <- matrix(yy[yfit], nrow = 3, )
  #   print(xx)
  x <- xx
  y <- yy
  if (length(x) != length(y)) 
    stop("dimension mismatch in x and y")
  xbar <- apply(x, 1, mean)
  ybar <- apply(y, 1, mean)
  xx <- sweep(xx, 1, xbar)
  x <- sweep(x, 1, xbar)
  y <- sweep(y, 1, ybar)
  R <- y %*% t(x)
  RR <- t(R) %*% R
  prj <- eigen(RR)
  prj$values[prj$values < 0 & prj$values >= -1e-12] <- 1e-12
  A <- prj$vectors
  b <- A[, 1]
  c <- A[, 2]
  A[1, 3] <- (b[2] * c[3]) - (b[3] * c[2])
  A[2, 3] <- (b[3] * c[1]) - (b[1] * c[3])
  A[3, 3] <- (b[1] * c[2]) - (b[2] * c[1])
  B <- R %*% A
  B <- sweep(B, 2, sqrt(prj$values), "/")
  b <- B[, 1]
  c <- B[, 2]
  B[1, 3] <- (b[2] * c[3]) - (b[3] * c[2])
  B[2, 3] <- (b[3] * c[1]) - (b[1] * c[3])
  B[3, 3] <- (b[1] * c[2]) - (b[2] * c[1])
  U <- B %*% t(A)
  xx <- U %*% xx
  
  x <- U %*% x
  frmsd <- sqrt(sum((x - y)^2)/dim(y)[2])
  #   cat("#rmsd= ", round(frmsd, 6), "\n")
  xx <- sweep(xx, 1, ybar, "+")
  return(xx)
}
rmsd.files <- function(files,ref=NULL,sub=heavy.atom)
{
  n=length(files)
  if(is.null(ref)) ref=read.frame(files[1],sub=sub)
  cl <- makeCluster(getOption("cl.cores", 6))
  res=parLapply(cl,1:n,rmsd.file.parellel,files,ref,sub)
  stopCluster(cl) 
  res=unlist(res)
  return(res)
}
rmsd.file.parellel <- function(i,files,ref,sub)
{
    source('rmsd.R')
    tem=read.frame(files[i],sub=sub)
    res=mrmsd(tem,ref)
    return(res)
}
read.frame <- function(frame,sub=NULL)
{
  temp=read.table(frame,header = F)
  temp=as.matrix(temp)
  rownames(temp)=NULL
  colnames(temp)=NULL
  n=dim(temp)[1]
  m=dim(temp)[2]
  if(n>m) temp=t(temp)
  if(!is.null(sub)) data=temp[,sub] else data=temp
  return(data)
} 
read.pdbxyz <- function(pdb,sub=NULL)
{
  require(bio3d)
  temp=read.pdb(pdb)
  xyz.temp=as.numeric(temp$xyz)
  xyz.temp=array(xyz.temp,dim=c(3,length(xyz.temp)/3))
  if(!is.null(sub)) xyz.temp=xyz.temp[,sub]
  return(xyz.temp)
}