source('./capt/load_data.R')
source('./capt/traj_jump.R')
source('./capt/ang_dis.R')
source('./capt/cirDen.R')
angDen <- function(v,adj=0.5,maxbw=709,kernel=c('gaussian','von','epanechnikov'))
{
  kernel=match.arg(kernel)
  cker=switch(kernel,von=1,gaussian=2,epanechnikov=3)
  #cat('kernel=',kernel,'\n')
  if(cker==1)
  {
    require(circular)
    require(NPCirc)
    cv=circular(v+pi,zero = 0)
    bw=bw.rt(cv)
    if(bw>maxbw) bw=maxbw
    denx=seq(-pi,pi-0.001,by=pi/500)+pi
    dres=den.circ(cv,bw=bw,t = denx)
    deny=dres$y
    denx=denx-pi
  }else{
      res=density(v)
      bw=res$bw
      v=c(v-2*pi,v,v+2*pi)
      v=v[v>=-pi-adj & v<=pi+adj]
      res=density(v,from=-pi,to=pi-0.001,n=1001,kernel=kernel,bw=bw) #kernel = 'epanechnikov'
      denx=res$x
      deny=res$y
      deny=deny[denx>=-pi & denx<=pi]
      denx=denx[denx>=-pi & denx<=pi]
  }
  return(list(denx=denx,deny=deny))
}
findPeaks <- function(x, thresh = 0) 
{
  pks <- which(diff(sign(diff(x, na.pad = FALSE)), na.pad = FALSE) < 0) + 2
  pks <- pks-1
  if (!missing(thresh)) {
    if (sign(thresh) < 0) 
      thresh <- -thresh
    pks <- pks[x[pks]>thresh]
  }
  return(pks)
}
get.partition <- function(intervals,denx,deny)
{
  inters=sort(intervals)
  n=length(inters)
  c <- NULL

  for(i in 1:n){
    if(i<n){
      a=inters[i]
      b=inters[i+1]
      da=ang_disVx(denx,a)
      db=ang_disVx(denx,b)
      aj=which.min(da)
      bj=which.min(db)
      
      if(bj<aj) bj=length(denx)
      
      inter1=deny[aj:bj]
      newxx=denx[aj:bj]
      aj=which.min(inter1)
      
      c[i]=newxx[aj]
    }else{
      
      a=inters[i]
      b=inters[1]
      da=ang_disVx(denx,a)
      db=ang_disVx(denx,b)
      aj=which.min(da)
      bj=which.min(db)
      
      newy=c(deny[aj:length(deny)],deny[1:bj])
      newx=c(denx[aj:length(deny)],denx[1:bj])
      
      bj=which.min(newy)
      c[i]=newx[bj]
    }
    
  }
  return(c)
}

find.peaks2 <- function(name,angi,v.ang=NULL,msize=0.01,path,kernel='gaussian',class='0',cluster=NULL,
                        trajectory=1,mprob)
{
#   cat('=====Parameters: \n')
#   cat('name:',name,'\n')
#   cat('angi:',angi,'\n')
#   cat('msize:',msize,'\n')
#   cat('kernel:',kernel,'\n')
#   cat('class:',class,'\n')
#   cat('mprob:',mprob,'\n')
#   cat('---------------\n')
  rxpeaks=NULL
  rypeaks=NULL
  xpeaks=NULL
  ypeaks=NULL
  score=0
  npeaks=1
  
  if(is.null(v.ang)){
    v.ang=load.angle(name=name,angi=angi,path=path)
  }
  if(length(v.ang)>0){
    
  if(!is.null(cluster) && as.numeric(class)>0){
    clus=(cluster==class)
    angV=v.ang[clus]
  }else{
    angV=v.ang
    clus=rep(T,length(angV))
  }
  res=angDen(angV,kernel = kernel)
  cdenx=res$denx
  cdeny=res$deny
  denx=c(cdenx-2*pi,cdenx,cdenx+2*pi)
  deny=c(cdeny,cdeny,cdeny)
  
  ppks=findPeaks(deny)
  nxs=1:length(denx)
  rslt=as.logical((denx>=-pi)*(denx<=pi))
  rmin=min(nxs[rslt])
  rmax=max(nxs[rslt])
  ppks=ppks[ppks>=rmin & ppks<=rmax]
  xpeaks=denx[ppks]
  
  ppks=sort(ppks)
  xpeaks=denx[ppks]
  xk=length(xpeaks)
  keep <- NULL
  keep[1]=ppks[1]
  
  ### delte replicated peaks
  if(xk>1)
  {
    for(i in 2:xk)
    {
      temp=denx[keep]
      dis=ang_disVx(temp,xpeaks[i])
      if(sum(dis<0.2)==0){
        keep=c(keep,ppks[i])
      }
    }
  }
  xpeaks=denx[keep]
  npeaks=length(xpeaks)
  partition=NULL
  
  if(npeaks>1)
  {
    partition=get.partition(xpeaks,cdenx,cdeny) 
    xpeaks=check.partition(xpeaks,v.ang,partition,class,cluster,msize)
    npeaks=length(xpeaks)
  }
  
  if(npeaks>1){
    partition=get.partition(xpeaks,cdenx,cdeny) 
    xpeaks=check2.partition(xpeaks,v.ang,partition,class,cluster,trajectory)
    npeaks=length(xpeaks)
    if(npeaks>1)
    {
      partition=get.partition(xpeaks,cdenx,cdeny)
      evalp=eval.partition(v.ang,partition,class,cluster,trajectory=trajectory,mprob=mprob)
      npeaks=length(unique(evalp$cluster[clus]))
      cluster=evalp$cluster
      score=evalp$score
    }
  }
  }
  if(npeaks==1) score=0
  return(list(npeaks=npeaks,xpeaks=xpeaks,cluster=cluster,
              score=score,partition=partition,denx=cdenx,deny=cdeny))
}
check2.partition <- function(xpeaks,traj_angles,partition,class,cluster,trajectory)
{
  part=sort(partition)
  
  if(is.null(cluster) || (as.numeric(class)==0)){
    n=length(traj_angles)
    ncluster=rep(paste(class,'1',sep=''),n)
    op_cluster=rep(T,n)
  }else{
    ncluster=cluster
    op_cluster=(cluster==class)
  }
  
  m=length(part)
  newc=paste(class,1:m,sep='')
  ncluster[op_cluster]=newc[1]
  
  check=rep(T,m)
  
  for(i in 2:m){
    c2=(traj_angles>part[i-1])&(traj_angles<=part[i])
    c2=c2&op_cluster
    ncluster[c2]=newc[i]
  }
  
  trans=frame.trans(cluster = ncluster,trajectory = trajectory,freq = T)
  
  #cat(trans)

    for(i in 2:m){
      c2=(traj_angles>part[i-1])&(traj_angles<=part[i])
      c2=c2&op_cluster
      
      if(sum(trans[newc[i],])==0)
      {
        icheck=(xpeaks>part[i-1] & xpeaks<=part[i])
        check[icheck]=F
      }
    } 
  
  if(sum(trans[newc[1],])==0){
    if(xpeaks[1]>part[1]) check[m]=F else check[1]=F
  }
  
  xpeaks=xpeaks[check]
  return(xpeaks)
}
check.partition <- function(xpeaks,traj_angles,partition,class,cluster,msize=0.01)
{
  part=sort(partition)
  
  if(is.null(cluster) || (as.numeric(class)==0)){
    n=length(traj_angles)
    ncluster=rep(paste(class,'1',sep=''),n)
    op_cluster=rep(T,n)
  }else{
    ncluster=cluster
    op_cluster=(cluster==class)
  }
  
  if(msize<1){
    MSIZE=sum(op_cluster)
    msize=msize*MSIZE
  }
  
  m=length(part)
  newc=paste(class,1:m,sep='')
  ncluster[op_cluster]=newc[1]
  
  check=rep(T,m)
  for(i in 2:m){
    c2=(traj_angles>part[i-1])&(traj_angles<=part[i])
    c2=c2&op_cluster
    ncluster[c2]=newc[i]
    if(sum(c2)<msize)
    {
      icheck=(xpeaks>part[i-1] & xpeaks<=part[i])
      check[icheck]=F
    }
  }
  
 if(sum(ncluster==newc[1])<msize){
   if(xpeaks[1]>part[1]) check[m]=F else check[1]=F
 }
 
 xpeaks=xpeaks[check]
 return(xpeaks)
}

eval.partition <- function(traj_angles,partition,class=0,cluster=NULL,trajectory,mprob=0.6)
{
  part=sort(partition)
  
  if(is.null(cluster) || (as.numeric(class)==0)){
    n=length(traj_angles)
    ncluster=rep(paste(class,'1',sep=''),n)
    op_cluster=rep(T,n)
  }else{
    ncluster=cluster
    op_cluster=(cluster==class)
  }
  
  m=length(part)
  newc=paste(class,1:m,sep='')
  ncluster[op_cluster]=newc[1]
  
  for(i in 2:m){
    c2=(traj_angles>part[i-1])&(traj_angles<=part[i])
    c2=c2&op_cluster
    ncluster[c2]=newc[i]
  }
  
  csize <- NULL
  for(i in 1:m)
  {
    csize[i]=sum(ncluster==newc[i])
  }
  names(csize)=newc
  csize=sort(csize)
  mc=names(csize)
  
  newcluster=ncluster
  for(i in 1:m)
  {
    newcluster[ncluster==mc[i]]=paste(class,i,sep='')
  }
  
  trans=frame.trans(cluster=newcluster,trajectory =trajectory,freq = T)
  probs=diag(trans)
  probs=probs[newc]
  min.prob=min(probs) ## why have NA's
  if(is.na(min.prob))
  {
    save(ncluster,newc,file='na.Rdata')
    cat('\n NA occurs....has been deleted...\n')
  }
  if(min.prob<mprob){
    merge=merge_state(trans,newc,newcluster,class,trajectory,mprob,op_cluster)
    newcluster=merge$cluster
    min.prob=merge$min.prob
  }
  return(list(cluster=newcluster,score=min.prob))
}
merge_state <- function(trans,newc,ncluster,class,trajectory,mprob=0.6,clus)
{
  probs=diag(trans)
  probs=probs[newc]
  states=names(probs)
  min.prob=min(probs)
  mc=length(newc)
  #cat('min.prob=',min.prob,'\n')
  while(min.prob<mprob && mc>1)
  {
    state=states[which.min(probs)]
    #cat('state=',state,'\n')
    trans[state,state]=0
    sprob=trans[state,newc]
    ncluster[ncluster==state]=states[which.max(sprob)]
    trans=frame.trans(cluster=ncluster,trajectory =trajectory,freq = T)
    
    sk=match(state,newc)
    newc=newc[-sk]
    mc=length(newc)
    
    probs=diag(trans)
    probs=probs[newc]
    states=names(probs)
    min.prob=min(probs)
    #cat('min.prob=',min.prob,'\n')
  }
  mc=unique(ncluster[clus])
  m=length(mc)
  csize <- NULL
  for(i in 1:m)
  {
    csize[i]=sum(ncluster==mc[i])
  }
  names(csize)=mc
  csize=sort(csize)
  mc=names(csize)
  
  newcluster=ncluster
  for(i in 1:m)
  {
    newcluster[ncluster==mc[i]]=paste(class,i,sep='')
  }
  return(list(cluster=newcluster,min.prob=min.prob))
}
