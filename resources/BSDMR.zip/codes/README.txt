The package BSDMR provides a full probabilistic framework for BSDMR detection. Users can install BSDMR by: 

> library(devtools)
> install_local('BSDMR_1.0.tar')


BSDMR contains a dataset of 1 pair of normal and tumor data generated according to th NHMM model. Users can load and explore this dataset by :

> load('example.RData')
> names(example)


Sampler() is the main function to estimate states and parameters in NHMM model. Users can generate or set initial values and encapsulate to a format needed in Sampler():
> # generate initial values randomly
> init <- InitialValues()     
> # generate initial values of partial parameters randomly
> # set mu_1= 0.3, mu_2=0.7, generate initial values of other parameters randomly
> init <- InitialValues(imuBH = 0.3,imuBL = 0.7) 

In addition, users can set Gibbs sampler control parameters by setting the correspond-
ing paramters in function Sampler(). See the details by 
>help(Sampler)

################Example###############
>  load('example.RData') 
> # 'example' contains all information needed in the detection and  
> # the format meets the requirements. If not, users can use IntegrateData to integrate informations.
> data <- IntegrateData(site = example$data, nX = example$nX,
+                        nY = example$nY, X = example$X, Y = example$Y)
> init <- InitialValues()
> GS <- Sampler(data = example, init = init, burnin = 5000, iter = 6000, filename = 'exampleout')

Following four files are created.
exampleout.pdf:
  trace plot of likelihood, posterior probability, the accuracy and all parameters of NHMM model including the burnin.
exampleout_con.pdf: 
  trace plot of likelihood, posterior probability, the accuracy and all parameters of NHMM model after the burnin.
exampleout-HMM.jpeg: 
  scatter plot of underlying probabilities (p_{X_{ij}},p_{Y_{ij}})  (left) and scatter of methylation levels (X/n_{X_{ij}},Y/n_{Y_{ij}}). Four colors represent four status.
exampleout.RData:
  estimates of all parameters, underlying probabilities and states in each iteration.

 Moreover, users can apply function call_DMCs() to sample states and underlying probability, given all the parameters in NHMM model. See the details by 
> help(call_DMCs)

 


