# DM

## Description

`DM` is an R function that aims to measure the dependence (association) between `x` and `y`. It integrates nine widely used algorithms (cor, scor, dcor, HHG, MIC, GR, RDC, XIcor and ACE) and two combined methods (harmonic mean and cauchy combination). 

## Usage

```R
DM(x,y)   # default harmonic
DM(x,y,method="mic", p.value=F)
DM(x,y,method="cauchy", p.value=T)
```

## Arguments

`x`                input data x
`y `                input data y, must have the same length with x
`method`     takes values in (cor, scor, dcor, hhg, mic, gr, rdc, xicor, ace, harmonic and cauchy ), default is harmonic
`p.value`   whether to calculate p-value, default is `FALSE`
`nperm`       number of permutations to get the approximated p-value, default is 200

## Return value

When `p.value=TRUE`, return a list containing 

- `method`       the method used for measuring the association
- `dm`           the value of the statistic defined by `method` 
- `p.value`      p-value of the association. 

When `p.value=FALSE`, return `dm`

## Requirement

```R
R(>=4.0.5)

XICOR (>=0.3.3)
HHG (>=2.3.2)
energy (>=1.7)
acepack (>=1.4.1)
minerva (>=1.5.8)
harmonicmeanp (>=3.0)
Rcpp (>=1.0.5)
```

## Note

Two samples must have the same sample size, and it should be noted that our `DM()` function will automatically delete missing values (`NA`/`NAN`). The logical value `TRUE`/`FALSE` will be treated as 1/0.

The `Gs.cpp` file is a necessary source file for `GR` and should be in the **same** directory as `DM.R`.

Some methods such as `MIC`, `HHG` and `RDC`, get p-value by permutation method, which may take some time.

## Author(s)

H. Li lihe317@zju.edu.cn and H. Jiang jianghj@zju.edu.cn

## Reference

H. Li#, H.X. Zhang# and H.Jiang* (2021). Combining Power of Different Methods to Detect Associations in Large Data Sets. *Briefings in Bioinformatics.*

We thanks to the amazing work done by MANY people in the open source community and the contributors of all related packages.
