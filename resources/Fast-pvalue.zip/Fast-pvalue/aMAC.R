require(Rcpp)
sourceCpp('MAC.cpp')

aMAC <- function(X,Y,pvalue=T,px=NULL,kp=20,B=200)
{
  Xx=as.matrix(X)
  d=ncol(Xx)
  if(d==1){
    res=.aMAC1(X,Y,pvalue,px,kp,B)
  } 
  if(d==2) res=.aMAC2(X,Y,pvalue,px,kp,B)
  if(d>2){
    res <- list(d)
    for(i in 1:d)
    {
      if(i==1) res[[i]]=.aMAC1(X[,1],Y[,1],pvalue,px,kp,B)
      if(i==2) res[[i]]=.aMAC2(X[,1:2],Y[,1:2],pvalue,px,kp,B)
      if(i>2){
        ids=c(i,1:(i-1))
        res[[i]]=.aMAC3(X[,1:i],Y[,1:i],pvalue,px,kp,B)
      }
    }
  }
  return(res)
}

.aMAC1 <- function(X,Y,pvalue=T,px=NULL,kp=30,B=200)
{
  xy=c(X,Y)
  xyord=order(xy)
  n=length(xy)
  m=length(X)
  if(is.null(px))
  {
    dn=floor(n/kp)
    index1=((1:kp)-1)*dn+1
    index=xyord[index1]
    px=xy[index]
  }
  Tv0=MAC1(X,Y,px)
  if(pvalue)
  {
    kT=length(Tv0)
    temp=array(0,dim=c(B,kT))
    for(b in 1:B)
    {
      sid=sample.int(n,m)
      x=xy[sid]
      y=xy[-sid]
      Tvs=MAC1(x,y,px)
      temp[b,]=Tvs
    }
    sds=apply(temp,2,sd)
    index=1:kT
    index=index[sds>0]
    stemp=temp[,index]
    cors=cor(stemp)
    mT=Tv0[index]
    mt=mean(mT[mT>-1])
    alpha=mean(cors)
    beta=1/alpha
    pv=1-pchisq(mt*beta,df=beta)
    return(list(Tv=mt,p.value=pv))
  }else{
    mt=mean(Tv0[Tv0>-1])
    return(mt)
  }
  
}
.aMAC2 <- function(X,Y,pvalue=T,px=NULL,kp=30,B=200)
{
  xy=rbind(X,Y)
  n=nrow(xy)
  m=nrow(X)
  if(is.null(px))
  {
    dn=floor(n/kp)
    x1=sort(xy[,1])
    y1=xy[,2]
    x1ordr=order(xy[,1])
    index1=((1:kp)-1)*dn+1
    px=cbind(x1[index1],y1[x1ordr[index1]])
  }
  Tv0=MAC2(X,Y,px)
  
  if(pvalue)
  {
    kT=length(Tv0)
    temp=array(0,dim=c(B,length(Tv0)))
    
    for(b in 1:B)
    {
      sid=sample.int(n,m)
      x=xy[sid,]
      y=xy[-sid,]
      Tvs=MAC2(x,y,px)
      temp[b,]=Tvs
    }
    
    sds=apply(temp,2,sd)
    index=1:kT
    index=index[sds>0]
    stemp=temp[,index]
    cors=cor(stemp)
    mT=Tv0[index]
    mt=mean(mT[mT>-1])
    alpha=mean(cors)
    beta=3/alpha
    pv=1-pchisq(mt*beta/3,df=beta)
    return(list(Tv=mt,p.value=pv))
  }else{
    mt=mean(Tv0[Tv0>-1])
    return(mt)
  }
}