#include <Rcpp.h>
#include <Rmath.h>
#include<iostream>
using namespace Rcpp;
NumericVector subVector(NumericVector x, IntegerVector sub)
{
  int i,n=x.size(),k=sub.size(),t=0;
  int m=n-k;
  IntegerVector flag(n);
  NumericVector res(m);
  for(i=0;i<n;i++) flag[i]=1;
  for(i=0;i<k;i++) flag[sub[i]]=0;
  for(i=0;i<n;i++){
    if(flag[i]==1){
      res[t]=x[i];
      t=t+1;
    }
  }
  return(res);
}

IntegerVector Rorder(NumericVector x){
  Rcpp::Environment base("package:base"); 
  Rcpp::Function order_r = base["order"];    
  int n=x.size();
  IntegerVector res(n);
  res=order_r(x);
  return(res);
}
// [[Rcpp::export]] 
NumericVector ChiTs(NumericVector x, NumericVector y, IntegerVector Index)
{
  int n=x.size(),m=Index.size();
  int t=-1,i,j,ii,i1,j1;
  int k=m/1*(m-1);
  double rx,ry,temp,xx,yy,c1,c2,c3,c0;
  NumericVector res(k);

    for(i=0;i<m;i++){
      for(j=0;j<m;j++){
        if(abs(i-j)>0)
        {
          t=t+1;
          i1=Index[i];
          j1=Index[j];
 
          xx=x[i1];
          yy=y[i1];
       
          rx=abs(xx-x[j1]);
          ry=abs(yy-y[j1]);
          c0=0;
          c1=0;
          c2=0;
          c3=0;

          for(ii=0;ii<n;ii++){
            if((abs(x[ii]-xx)<=rx)){
              if((abs(y[ii]-yy)<=ry)) c0++; else c1++;
            }else{
              if((abs(y[ii]-yy)<=ry)) c2++; else c3++;
              }
          }
          xx=(c1*c2-c0*c3);
          temp=(c0+c1)*(c2+c3)*(c0+c2)*(c1+c3);
          if(temp>0) res[t]=n*xx*xx/temp; else {res[t]=-1;}
        }
  }
}
    return(res);
}
// [[Rcpp::export]] 
NumericMatrix PermuT(NumericVector x, NumericVector y, IntegerVector Index, int B)
{
  int b,n=x.size(),m=Index.size();
  int kt=m/1*(m-1);
  IntegerVector sid(n);
  NumericVector pu(n);
  if(B<1) B=100;
  NumericMatrix rest(B,kt);
  for(b=0;b<B;b++)
  {
    pu=Rcpp::runif(n,0,1);
    sid=Rorder(pu)-1;
    rest(b,_)=ChiTs(x,y[sid],Index);
  }
  return(rest);
}
