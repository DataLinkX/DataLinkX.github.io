### Examples for using cHHG, and aMAC.
source("aMAC.R")
source("cHHG.R")
### cHHG

x=rnorm(200)
y=x+rnorm(200)
res1=cHHG(x,y,kp=50,B=200) ### kp is the nubmer of test points, B is the number of permutations for estimating correlations

### aMAC 

x=rnorm(200)
y=rnorm(200)
res2=aMAC(x,y,kp=30,B=200) ## kp is the nubmer of test points, B is the number of permutations for estimating correlations