File ChiTs.cpp contains functions for computing local statistics for HHG.
The main function for HHG is cHHG, in file cHHG.R.

File MAC.cpp contains functions for computing local statistics for MAC.
The main function for MAC is aMAC, in file aMAC.R.
