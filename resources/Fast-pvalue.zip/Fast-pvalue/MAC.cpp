#include <Rcpp.h>
#include "math.h"
#include<iostream>
using namespace Rcpp;

double dist(NumericVector x, NumericVector y)
{
  int i,k=x.size();
  double res = 0;
  for (i = 0; i<k; i++)
    res = res + (x[i] - y[i])*(x[i] - y[i]);
  res=sqrt(res);
  return(res);
}

NumericVector counts2(double xx, double yy, double rx, double ry, NumericMatrix X)
{
  int i,n=X.nrow();
  NumericVector x(n);
  NumericVector y(n);
  x=X(_,0);
  y=X(_,1);
  NumericVector count(4);
  for(i=0;i<4;i++)count[i]=0;
  for(i=0;i<n;i++){
    if((abs(x[i]-xx)<=rx)){
      if((abs(y[i]-yy)<=ry)) count[0]=count[0]+1; else count[1]=count[1]+1;
    }else{
      if((abs(y[i]-yy)<=ry)) count[2]=count[2]+1; else count[3]=count[3]+1;
    }
  }
  return(count);
}

NumericVector counts3(double xx, NumericVector yy, double rx, double ry, NumericMatrix X)
{
  int i,n=X.nrow(), d=X.ncol();
  NumericVector x=X(_,0);
  NumericMatrix y=X(_,Range(1,d-1));
  NumericVector count(4);
  for(i=0;i<4;i++) count[i]=0;
  for(i=0;i<n;i++){
    if(abs(x[i]-xx)<=rx){
      if(dist(yy,y(i,_))<=ry) count[0]=count[0]+1; else count[1]=count[1]+1;
    }else{
      if(dist(yy,y(i,_))<=ry) count[2]=count[2]+1; else count[3]=count[3]+1;
    }
  }
  return(count);
}

NumericVector counts1(double px, NumericVector x, double r)
{
  NumericVector res(2);
  int i,n=x.size();
  res[0]=0;
  res[1]=0;
  
  for(i=0;i<n;i++)
  {
    if(abs(x[i]-px)<=r) res[0]=res[0]+1; else res[1]=res[1]+1;
  }
  return(res);
}

// [[Rcpp::export]]
NumericVector MAC1(NumericVector x, NumericVector y, NumericVector px)
{
  int i,j,k,s,n,m,t;
  double rx,Ri2,Ri1,rate;
  n=x.size();
  m=y.size();
  k=px.size();
  s=k*(k-1);
  rate=1.0*n/(n+m);
  NumericVector res(s);
  NumericVector countx(2);
  NumericVector county(2);
  for(i=0;i<s;i++) res[i]=0;
  t=-1;
  for(i=0;i<k;i++){
    for(j=0;j<k;j++){
         if(abs(i-j)>0){
           t=t+1;
            rx=abs(px[i]-px[j]);
            countx=counts1(px[i], x, rx);
            county=counts1(px[i], y, rx);
            Ri1=countx[0]+county[0];
            Ri2=countx[1]+county[1];
            if(Ri1*Ri2>0){
              rx=0;
              rx=rx+(countx[0]-rate*Ri1)*(countx[0]-rate*Ri1)/(rate*Ri1);
              rx=rx+(county[0]-(1-rate)*Ri1)*(county[0]-(1-rate)*Ri1)/((1-rate)*Ri1);
              rx=rx+(countx[1]-rate*Ri2)*(countx[1]-rate*Ri2)/(rate*Ri2);
              rx=rx+(county[1]-(1-rate)*Ri2)*(county[1]-(1-rate)*Ri2)/((1-rate)*Ri2);
              res[t]=rx;
            }else{res[t]=-1;}
        }}}
  return(res);
}

// [[Rcpp::export]]
NumericVector MAC2(NumericMatrix X, NumericMatrix Y, NumericMatrix P)
{
  int k,i,j,p,n,m,N,s,t,flage=0;
  NumericVector countx(4);
  NumericVector county(4);
  double rx,ry,Ri,rate;
  
  k=P.nrow();
  n=X.nrow();
  m=Y.nrow();
  s=(k-1)*k;
  t=-1;
  N=n+m;
  rate=1.0*n/N;
  NumericVector res(s);
  NumericVector px(k);
  NumericVector py(k);
  px=P(_,0);
  py=P(_,1);
  
  for(i=0;i<s;i++) res[i]=0;
  
  for(i=0;i<k;i++){
    for(j=0;j<k;j++){
      if(abs(i-j)>0){
        t=t+1;
        rx=abs(px[i]-px[j]);
        ry=abs(py[i]-py[j]);
        countx=counts2(px[i],py[i],rx,ry,X);
        county=counts2(px[i],py[i],rx,ry,Y);
        flage=0;
        for(p=0;p<4;p++){
          Ri=countx[p]+county[p];
          if(Ri>0 && flage==0){
            res[t]=res[t]+(countx[p]-rate*Ri)*(countx[p]-rate*Ri)/(rate*Ri);
            res[t]=res[t]+(county[p]-(1-rate)*Ri)*(county[p]-(1-rate)*Ri)/((1-rate)*Ri); 
          }else{
            res[t]=-1;
            flage=1;
            } 
        }
      }
    }
  }
  return(res);
}