require(Rcpp)
sourceCpp('ChiTs.cpp')

cHHG <- function(x,y,kp=30,B=200)
{
  n=length(x)
  if(kp>n) kp=n
  xord=order(x)
  dn=floor(n/kp)
  index1=((1:kp)-1)*dn+1
  index1=xord[index1]-1
  Tv0=ChiTs(x,y,index1)
  kT=length(Tv0)
  temp=PermuT(x,y,index1,B)
  sds=apply(temp,2,sd)
  index=1:kT
  sindex1=index[sds>0]
  sindex2=index[Tv0>0]
  sindex=unique(c(sindex1,sindex2))
  stemp=temp[,sindex]
  cors=cor(stemp)
  mT=Tv0[sindex]
  mt=mean(mT)
  alpha=mean(cors)
  beta=1/alpha
  pv=1-pchisq(mt*beta,df=beta)
  return(pv)
}